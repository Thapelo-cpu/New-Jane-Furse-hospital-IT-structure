# Contents

[PART A- PROJECT CHARTER
[2](#part-a--project-charter)](#part-a--project-charter)

[Project charter overview and purpose
[2](#project-charter-overview-and-purpose)](#project-charter-overview-and-purpose)

[Project Objectives [2](#project-objectives)](#project-objectives)

[Scope and Deliverables
[2](#scope-and-deliverables)](#scope-and-deliverables)

[Stakeholder Register [3](#stakeholder-register)](#stakeholder-register)

[Risks, Assumptions and Constraints
[4](#risks-assumptions-and-constraints)](#risks-assumptions-and-constraints)

[Budget Overview [5](#budget-overview)](#budget-overview)

[Timeline and Milestones
[6](#timeline-and-milestones)](#timeline-and-milestones)

[Success Criteria [6](#success-criteria)](#success-criteria)

[PART B- PROJECT PLAN [7](#part-b--project-plan)](#part-b--project-plan)

[Project Execution Approach
[7](#project-execution-approach)](#project-execution-approach)

[Phase Structure [7](#phase-structure)](#phase-structure)

[WORK BREAKDOWN STRUCTURE
[8](#work-breakdown-structure)](#work-breakdown-structure)

[Resource Management [9](#resource-management)](#resource-management)

[Quality Management [10](#quality-management)](#quality-management)

[Change Management [11](#change-management)](#change-management)

[Procurement Management
[11](#procurement-management)](#procurement-management)

[PART C- Project Proposals
[12](#part-c--project-proposals)](#part-c--project-proposals)

[Proposals Introduction
[12](#proposals-introduction)](#proposals-introduction)

[Proposal 1: Telemedicine Expansion to Five Additional Feeder Clinics
[12](#proposal-1-telemedicine-expansion-to-five-additional-feeder-clinics)](#proposal-1-telemedicine-expansion-to-five-additional-feeder-clinics)

[Proposal 2: Internet Backbone Upgrade
[13](#proposal-2-internet-backbone-upgrade)](#proposal-2-internet-backbone-upgrade)

[Proposal 3: NHLS Laboratory Integration
[14](#proposal-3-nhls-laboratory-integration)](#proposal-3-nhls-laboratory-integration)

[PROPOSALS SUMMARY AND PRIORISATISATION
[15](#proposals-summary-and-priorisatisation)](#proposals-summary-and-priorisatisation)

[PART D- PROJECT PLAN
[16](#part-d--project-plan)](#part-d--project-plan)

[Executive Summary [16](#executive-summary)](#executive-summary)

[PROJECT BACKGROUND AND CONTEXT
[16](#project-background-and-context)](#project-background-and-context)

[Implementation Approach
[17](#implementation-approach)](#implementation-approach)

[Deliverables and Outcomes
[17](#deliverables-and-outcomes)](#deliverables-and-outcomes)

[TRAINING OUTCOMES [18](#training-outcomes)](#training-outcomes)

[Lessons Learned [19](#lessons-learned)](#lessons-learned)

[Recommendations [20](#recommendations)](#recommendations)

[Conclusion [20](#conclusion)](#conclusion)

[References [20](#references)](#references)

## 

## PART A- PROJECT CHARTER 

### Project charter overview and purpose

The Sekhukhune District Hospital in remote Limpopo serves a large rural
population through 400 staff and 20 wards, yet operates with severely
outdated IT. Only 15 ageing computers, three printers, and three ICT
support staff maintain operations. Cybersecurity, modern data storage,
and reliable connectivity are absent, placing patient records at risk.

This project will deploy a modern, secure, and sustainable IT
infrastructure bridging the digital divide between the hospital and
municipality's network. The primary purpose is to establish a dedicated
high-speed fibre connection over the 1 km from the municipality to the
hospital, enabling faster connectivity than commercial carriers offer.

Beyond connectivity, the project will deploy modern workstations,
security appliances, structured data storage, and a trained local ICT
team. The ultimate purpose to ensure uninterrupted care while
safeguarding sensitive data in compliance with national healthcare IT
governance standards.

###  Project Objectives

Objectives are organized around five pillars :

**Connectivity:** Establish a dedicated fibre link from the municipality
to the hospital for reliable, low latency access.

**Infrastructure Modernisation:** Replace ageing computers with secure
workstations, install networked printers, and deploy centralised storage
and backup.

**Cybersecurity:** Implement firewalls, intrusion detection, endpoint
protection, and secure wireless infrastructure

**Operational Efficiency:** Integrate and stabilise software for
operations, finance, supply chain, and patient record management.

**Capacity Building:** Train the three ICT staff in installation,
troubleshooting, and hardware replacement.

### Scope and Deliverables 

In Scope

-Fibre network splicing and extension from municipality to hospital (1
km)

-Procurement and installation of modern workstations, laptops, and
printers

-Network core infrastructure: switches, router, firewall, and wireless
access points

-Server and storage infrastructure with cloud backup integration

-Endpoint security software, network monitoring, and intrusion detection

-Structured cabling and wireless coverage across 20 wards and 5 offices

-Software licensing, configuration, and integration of hospital
management systems

-ICT staff training programme and technical documentation

Out of Scope

-Construction of new buildings or civil engineering works

-Medical equipment or clinical devices unrelated to IT

-Full-scale cloud migration (hybrid backup only)

-District-wide network expansion beyond the hospital site

Key Deliverables

| **Deliverable**               | **Description**                                                  | **Due Date** |
|-------------------------------|------------------------------------------------------------------|--------------|
| Project Charter               | Formal authorisation and high level scope                        | Month 1      |
| Network Architecture Diagrams | Logical, Physical and cloud diagrams                             | Month 2      |
| Procurement Plan              | Hardware, Software and service agreements                        | Month 2      |
| Infrastructure Deployment     | Installed and tested network, servers and endpoints              | Month 6      |
| Security Policies & SOPs      | Access control, incident response and continuity plans           | Month 7      |
| Training Completion           | Certified ICT staff with installation and troubleshooting skills | MONTH 9      |
| Final Handover & Report       | Complete technical documentation and user acceptance             | Month 12     |

### Stakeholder Register

Stakeholder engagement is important given the political and social
dimensions of this remote infrastructure.

| **NAME/ROLE**            | **ORGANISATION**             | **INTERESTS & EXPECTATIONS**                               | **INFLUENCE** |
|--------------------------|------------------------------|------------------------------------------------------------|---------------|
| Hospital CEO             | SEKHUKHUNE DISTRICT HOSPITAL | Uninterrupted care, data security, reliable IT             | High          |
| ICT MANAGER              | SEKHUKHUNE DISTRICT HOSPITAL | Modern infrastructure, manageable workload, staff training | High          |
| ICT SUPPORT STAFF (3)    | SEKHUKHUNE DISTRICT HOSPITAL | Skills development,clear documentation                     | Medium        |
| MUNICIPAL IT DIRECTOR    | SEKHUKHUNE MUNICIPALITY      | Succesful network splice, SLA compliance                   | High          |
| OpenServe Representative | OpenServe                    | Backhaul connectivity service up time                      | High          |
| FINANCE OFFICERS         | SEKHUKHUNE DISTRICT HOSPITAL | Accurate financial systems, audit trails                   | Medium        |
| SUPPLIERS                | External partners            | Reliable intranet access                                   | Low           |
| PATIENTS& COMMUNITY      | SEKHUKHUNE DISTRICT HOSPITAL | Reduced waiting times, continuity of care                  | Medium        |

### Risks, Assumptions and Constraints

| **RISK**                              | **LIKELIHOOD** | **IMPACT** | **MITIGATION STRATEFY**                                        |
|---------------------------------------|----------------|------------|----------------------------------------------------------------|
| Social or political opposition        | Medium         | High       | Engage community leaders align with local deployment goals     |
| Budget overruns from remote logistics | High           | Medium     | Fixed price contracts,10% contingency, phased procurement      |
| Skills gaps among ICT staff           | Medium         | High       | Structured 9 month training vendor support retainer for year 1 |
| Cybersecurity breaches                | High           | Medium     | Layered security regular patching, incident response SOPS      |
| Power Instability                     | High           | Medium     | UPS for all critical infrastructure, generator ready design    |
| Vendor delays or Shortages            | Medium         | Medium     | Multivendor sourcing, early procurement buffer stock           |

Assumptions and Constraints

**-**The municipality grants formal permission to splice and extend its
fibre network to the hospital.

-OpenServe remains the sole available carrier for backhaul connectivity
in the district.

-The hospital’s electrical supply can support the new IT load with UPS
backup.

-Budget is constrained by the public sector procurement regulations and
must demonstrate value for money.

-All solutions must comply with POPIA and national health data
standards.

### Budget Overview

| **Budget Category**             | **Estimated(ZAR)** | **Notes**                                              |
|---------------------------------|--------------------|--------------------------------------------------------|
| Fibre infrastructure & Splicing | R 180 000          | 1 Km Fibre run, Termination, Testing                   |
| Network Hardware(Core)          | R 250 000          | Switches, routers, Firewall, WAPs, UPS                 |
| End-User Devices                | R 320 000          | 25 Workstations, 8 Printers, Mobile Carts              |
| Server & Storage                | R 190 000          | On Premises servers, NAS backup, cloud subscription    |
| Software Licensing & Security   | R 140 000          | OS licences, Endpoint protection, monitoring           |
| Training & Change Management    | R 60 000           | ICT staff certification, Workshops                     |
| Contingency (10%)               | R 114 000          | Reserve for remote logistics and currency fluctuations |
| **Total Estimated Budget**      | **R 1 254 000**    | **Exclusive of VAT and ongoing operational costs**     |

### Timeline and Milestones

| **Phase/Milestone**                     | **Months** | **Duration** | **Key Activities**                                              |
|-----------------------------------------|------------|--------------|-----------------------------------------------------------------|
| **Phase 1**: Initiation & Planning      | M1-M2      | 2 months     | Charter, stakeholder alignment, site survey, design tendering   |
| **Milestone:** Charter approved         | M2         | \-           | Sign off by Hospital CEO and Municipal IT Director              |
| **Phase 2:** Procurement & Preparation  | M3-M4      | 2 months     | Vendor Selection, orders, cabling prep, training curriculum     |
| **Milestone**: Hardware Delivered       | M4         | \-           | All equipment onsite and inspected                              |
| **Phase 3 :** Infrastructure Deployment | M5-M7      | 3 months     | Fibre splicing, network install, server deploy, security config |
| **Milestone:** Network Live             | M7         | \-           | End to end connectivity tested and accepted                     |
| **Phase 4:** Integration & Testing      | M8-M9      | 2 moths      | Software integration, data migration, UAT, security audit       |
| **Milestone:** System Accepted          | M9         | \-           | User acceptance sign-off by all departments                     |
| **Phase 5:** Handover &Sustainability   | M10-M12    | 3 months     | Documentation ,SOPs, Warranty transfer, Monitoring              |
| **Milestone:** Project closure          | M12        | \-           | Formal handover ,sustainability plan activated                  |

###  Success Criteria

Project success will be evaluated against these measurable criteria at
Month 12 and during a six-month post-implementation review:

\-**Network Performance:** Minimum 100 Mbps symmetrical throughput with
99.5% uptime.

\-**Security Posture**: All systems pass a vulnerability assessment with
zero critical unpremeditated vulnerabilities.

\-**User Adoption:** 100% of staff transitioned to new workstations and
platforms with documented training completion.

\-**ICT Capability:** All three ICT staff demonstrate competency in
installing, troubleshooting, and replacing equipment without external
help.

**-Data Integrity:** Historical patient and financial data migrated with
100% accuracy and zero unrecoverable loss.

**-Compliance:** Infrastructure and processes meet POPIA requirements
and national health IT governance standards.

**-Sustainability**: A continuity plan and 12-month vendor support
retainer are in place.

Meeting these criteria will close the digital divide between rural and
urban facilities and establish a replicable model for remote
communities.

## PART B- PROJECT PLAN

### Project Execution Approach

Methodology:

The project follows a hybrid methodology combining predictive(
Waterfall) planning for infrastructure deployment with agile sprints for
software configuration and user training. This dual approach
accommodates the fixed sequence nature of cabling and hardware
installation while allowing iterative refinement of system
configuration.

### Phase Structure 

| **Phase**            | **Description**                                          | **Duration** | **Key Gate**                 |
|----------------------|----------------------------------------------------------|--------------|------------------------------|
| Initiation           | Finalise Charter, Secure approval, Mobilise team         | 2 weeks      | Charter sign off             |
| Planning             | Detailed design procurement specs, resource planning     | 4 weeks      | Baseline plan approved       |
| Execution            | Installation, Configuration, integration, training       | 16 weeks     | System integration test pass |
| Monitoring & Control | Ongoing, tracking risk management, change control        | continuous   | Status reports/phase gates   |
| Closure              | Handover, documentation, lessons learned, warranty start | 2 weeks      | Final acceptance sign off    |

### WORK BREAKDOWN STRUCTURE

**The WBS decomposes the project into manageable work packages organised
by phase and deliverable area**

| **WBS CODE** | **WORK PACKAGE**                                          | **OWNER**            | **ESTIMATED EFFORT (DAYS)** |
|--------------|-----------------------------------------------------------|----------------------|-----------------------------|
| 1.1          | Project Charter Finalisation                              | Project Manager      | 5                           |
| 1.2          | Stakeholder onboarding                                    | Project Manager      | 3                           |
| 2.1          | Network architecture design                               | Network Engineer     | 10                          |
| 2.2          | Hardware procurement specification                        | IT Leader            | 8                           |
| 2.3          | Vendor evaluation and selection                           | Procurement officer  | 10                          |
| 2.4          | Risk and quality planning                                 | Project Manager      | 5                           |
| 3.1          | Structured cabling installation                           | Cabling Contractor   | 15                          |
| 3.2          | Server room setup and rack installation                   | Infrastructure team  | 10                          |
| 3.3          | Network equipment deployment Network Engineer and testing | Network Engineer     | 8                           |
| 3.4          | HER system installation and configuration                 | Application Team     | 12                          |
| 3.5          | Telemedicine platform setup                               | Application Team     | 7                           |
| 3.6          | User Training( Clinical and admin staff)                  | Training Leader      | 10                          |
| 3.7          | System Integration testing                                | QA Leader            | 8                           |
| 4.1          | Progress reporting and Variance analysis                  | Project Manager      | ongoing                     |
| 4.2          | Change request management                                 | Change control board | ongoing                     |
| 5.1          | Operational handover and documentation                    | Project Manager      | 5                           |
| 5.2          | Lessons learned workshop                                  | Project Manager      | 2                           |

### Resource Management

**Project Team Structure**

| **Role**                | **Name/Allocation**     | **Responsibility**                              |
|-------------------------|-------------------------|-------------------------------------------------|
| Project Sponsor         | Hospital CEO            | Executive oversight, budget approval            |
| Project Manager         | T Molefe (Full time)    | Planning, Execution, Reporting, Risk Management |
| IT Leader               | K Nkosi (Full time)     | Technical architecture, Vendor liaison          |
| Network Engineer        | P Dlamini (Part time)   | Network design, deployment, testing             |
| Application Team Leader | S Mahlangu ( Full time) | HER and telemedicine configuration              |
| Training Lead           | N Sithole ( Part time)  | Curriculum, Development, Delivery, assessment   |
| QA LEADER               | R Mokoena ( Part time)  | Test Planning execution, defect tracking        |
| Procurement Officer     | L Zwane ( Part time)    | Vendor Management purchasing, Contracts         |

**SCHEDULE AND MILESTONES**

| **Milestones**            | **Target Date** | **Predecessor**  | **Deliverable**                  |
|---------------------------|-----------------|------------------|----------------------------------|
| M1:Project Kick off       | Week 1          | Charter sign off | Kick off meeting minutes         |
| M2:Baseline Plan approved | Week 6          | M1               | Approved Project Plan            |
| M3: Procurement Complete  | Week 10         | M2               | Purchase Orders Issued           |
| M4:Cabling Complete       | Week 14         | M3               | Cabling Certification report     |
| M5: Network Live          | Week 17         | M4               | Network acceptance               |
| M6:HER Config Complete    | Week 20         | M5               | EHR Configuration Sign off       |
| M7:Training Complete      | Week 22         | M6               | Training Completion records      |
| M8: SIT pass              | Week 24         | M7               | Integration test report          |
| M9: Go live               | Week 25         | M8               | Go live Authorisation            |
| M10: Project Closure      | Week 26         | M9               | Closure report and handover pack |

### Quality Management

**Quality Standards**

-ISO 27001 for Information Security Management

-POPIA(Protection of Personal Information ACT) Compliance for patient
data

-South African National Health Insurance(NHI) interoperability standards

-ITU-T recommendations for network infrastructure performance

-All Cabling to comply with SANS 101 42-1 code

**Quality Assurance Activities**

| **Activity**            | **Frequency**            | **Owner**                      |
|-------------------------|--------------------------|--------------------------------|
| Design Reviews          | Per Phase                | IT Lead                        |
| Code and Configuration  | Weekly                   | Application Team Lead          |
| Cabling Inspections     | Daily during integration | Network Engineer               |
| Integration test Cycles | 3 cycles before go live  | QA Lead                        |
| User acceptance testing | Pre go live              | Hospital Staff Representatives |

**COMMUNICATION PLAN**

| **Communication**           | **Audience**                   | **Frequency** | **Medium**          |
|-----------------------------|--------------------------------|---------------|---------------------|
| Executive Status Report     | Project Sponsor/Hospital Board | Bi Weekly     | Email +meeting      |
| Project team stand up       | Core Project team              | Daily         | In person/video     |
| Steering Committee Review   | Steering Committee             | Monthly       | Formal Presentation |
| Stakeholder newsletter      | All stakeholders               | Monthly       | Email               |
| Risk and Issue escalation   | Project Manager/Sponsor        | As needed     | Email +meeting      |
| Change request Notification | Change Control Board           | As needed     | Email               |

**Risk Response Strategies**

| **Risk**                          | **Probability** | **Impact** | **Response Strategy**                                |
|-----------------------------------|-----------------|------------|------------------------------------------------------|
| Vendor delivery delays            | Medium          | High       | Pre qualify backup vendors, early order placement    |
| Budget overrun due to scope creep | Medium          | High       | Strict Change control;10% management reserve         |
| Staff resistance to new systems   | High            | Medium     | Early Engagement champions programme, phased rollout |
| Power outages during installation | High            | Medium     | UPS deployment first; generator backup schedule      |
| Data migration errors             | Medium          | High       | Trial migration; data validation scripts; rollback   |
| Network security breach           | Low             | Critical   | Firewall and ids deployment; penetration testing     |

### Change Management

All changes to scope, schedule, or budget must follow the formal change
control process. Requests are submitted to the Change Control Board
(CCB), which comprises the Project Manager, IT Lead, and Project
Sponsor. The CCB evaluates impact, approves or rejects, and updates the
baseline accordingly.

1.Submit change request form with impact assessment

2.CCB reviews and records decision within 5 business days

3.Approved changes are integrated into the project plan

4.Affected stakeholders are notified of approved changes

5.Project baseline is updated to reflect approved changes

### Procurement Management

Procurement follows the Limpopo Provincial Supply Chain Management
Policy. All purchases above ZAR 500,000 require three competitive
quotations. The procurement timeline is integrated into the master
schedule, with lead times identified for critical items (servers,
switches, EHR software licence).

**PROJECT CLOSURE**

-Obtain final acceptance sign-off from the Hospital CEO

-Hand over all project documentation, as built diagrams, and warranty
certificates

-Conduct lessons learned workshop with all team members

-Release project resources and close contracts

-Archive project records in the hospital governance repository

-Transition to operational support and warranty period

## PART C- Project Proposals

###  Proposals Introduction

This section presents three strategic project proposals for the
continued advancement of IT infrastructure and digital health services
at Sekhukhune District Hospital. Building upon the success of the
initial IT Infrastructure Project, these proposals address identified
gaps, emerging needs, and opportunities for expansion that will further
enhance healthcare delivery and operational efficiency.

Each proposal includes a clear problem statement, proposed solution,
expected benefits, cost estimate, and timeline. The proposals are
designed to be actionable, independently fundable, and aligned with the
South African National Digital Health Strategy and the Limpopo
Provincial Health IT Roadmap.

###  Proposal 1: Telemedicine Expansion to Five Additional Feeder Clinics

**Background and Problem Statement**

The initial project established a telemedicine platform connecting the
hospital to three feeder clinics. Clinical uptake has exceeded
projections by 40%, with an average of 28 specialist consultations per
week. However, five additional clinics in the Sekhukhune District remain
without telemedicine access, forcing patients in those areas to travel
over 60 km for specialist consultations. This results in delayed
diagnoses, high transport costs for patients, and avoidable disease
progression.

**Proposed Solution**

Extend the telemedicine platform to five additional primary healthcare
clinics: Masha Clinic, Motetema Clinic, Tafelkop Clinic, Elandskraal
Clinic, and Driekop Clinic. Each site will receive a telemedicine
workstation (high-definition camera, examination peripherals, and a
dedicated video conferencing unit), a VSAT or LTE internet link, and
on-site training for clinic nurses.

**Expected Benefits**

\- Reduce average patient travel distance from 60 km to under 5 km for
specialist consultations

\- Increase specialist consultation capacity by an estimated 50
consultations per week

\- Improve early diagnosis rates for chronic conditions (TB, diabetes,
hypertension)

\- Reduce patient transportation costs by an estimated ZAR 1.2 million
annually across the district

**Cost Estimate**

| **Item**                                                 | **Unit Cost (ZAR)** | **Quantity** | **Total (ZAR)** |
|----------------------------------------------------------|---------------------|--------------|-----------------|
| Telemedicine workstation(Camera, Perpherals, video unit) | R 35 000            | 5            | R 175 000       |
| VSAT/LTE INTERNET installation per site                  | R 25 000            | 5            | R 125 000       |
| 12 Month internet per site                               | R 48 000            | 5            | R 240 000       |
| On-site training(nurses and port staff)                  | R 15 000            | 5            | R 75 000        |
| Project management and deploy                            |                     |              | R 85 000        |
| TOTAL                                                    |                     |              | R 700 000       |

**Timeline**

12 weeks from approval: 2 weeks planning and procurement, 6 weeks
installation and configuration, 2 weeks training, 2 weeks testing and
go-live.

### Proposal 2: Internet Backbone Upgrade

**Background and Problem Statement**

The current 100 Mbps internet link supports EHR access and telemedicine
for the three connected clinics but is approaching capacity during peak
hours (09:00-12:00). Network monitoring shows average utilisation at
72%, with peaks reaching 94%, causing occasional video quality
degradation in telemedicine sessions and slow EHR response times. The
proposed telemedicine expansion (Proposal 1) would push peak utilisation
beyond sustainable levels.

**Proposed Solution**

Upgrade the hospital's internet backbone from 100 Mbps to 500 Mbps
through a fibre-to-the-premises (FTTP) connection provided by the
provincial broadband network. The upgrade includes replacing the edge
router, reconfiguring the firewall, and implementing quality-of-service
(QoS) policies that prioritise clinical traffic (EHR and telemedicine)
over administrative traffic.

**Expected Benefits**

\- Eliminate peak-hour network congestion and telemedicine video
degradation

\- Reduce EHR average page load time from 3.2 seconds to under 1 second

\- Support the expanded telemedicine programme (Proposal 1) without
performance impact

\- Future-proof the network for upcoming NHLS integration and additional
digital services

**COST BENEFITS**

| ITEM                                              | COST (ZAR) |
|---------------------------------------------------|------------|
| FTTP Installation (Provincial broadband provider) | R 180 000  |
| Edge router replacement                           | R 65 000   |
| Firewall reconfiguration and QoS setup            | R 25 000   |
| Testing and Commissioning                         | R 15 000   |
| 12 Month recurring bandwidth cost (500 Mbps)      | R 300 000  |
| TOTAL                                             | R 585 000  |

**Timeline**

6 weeks from approval: 2 weeks procurement and scheduling with
provincial provider, 2 weeks installation, 1 week configuration and
testing, 1 week commissioning and monitoring.

###  Proposal 3: NHLS Laboratory Integration

**Background and Problem Statement**

Currently, laboratory results from the National Health Laboratory
Service (NHLS) are received as printed paper reports, which are manually
filed into patient records. This process introduces delays of 24-72
hours between result availability and clinician access, increases the
risk of lost results, and prevents automated alerts for critical values.
The hospital processes approximately 800 lab requests per week, making
manual handling a significant operational burden.

**Proposed Solution**

Implement an automated HL7-based interface between the hospital EHR
system and the NHLS Laboratory Information System (LIS). This
integration will enable electronic lab order submission, automated
result retrieval, result display within the patient's EHR record, and
critical-value alerting to the requesting clinician via SMS and
in-system notification.

**Expected Benefits**

\- Reduce lab result turnaround time from 24-72 hours to under 4 hours
(real-time on completion)

\- Eliminate lost lab results through digital tracking and archival

\- Enable critical-value alerts, reducing time-to-treatment for abnormal
results

\- Save an estimated 120 staff hours per week currently spent on manual
filing

\- Support epidemiological surveillance through automated data feeds to
district health systems

**COST ESTIMATE**

| Item                                    | Cost (ZAR) |
|-----------------------------------------|------------|
| HL7 interface engine licence ( 1 year)  | R 120 000  |
| Interface development and configuration | R 95 000   |
| NHLS connectivity and testing fees      | R 40 000   |
| Alert system(SMS gateway integration)   | R 30 000   |
| Staff training on electronic ordering   | R 25 000   |
| Project Management                      | R 40 000   |
| TOTAL                                   | R 350 000  |

**TIMELINE**

10 weeks from approval: 2 weeks planning and NHLS coordination, 3 weeks
interface development, 2 weeks testing ( including parallel run with
manual process), 1 week training, 2 weeks monitored go-live

### PROPOSALS SUMMARY AND PRIORISATISATION 

| PROPOSAL                    | COST(ZAR)   | DURATION | PRIORITY | DEPENDENCIES              |
|-----------------------------|-------------|----------|----------|---------------------------|
| Telemedicine Expansion      | R 700 000   | 12 WEEKS | HIGH     | NONE(STANDARD ALONE)      |
| Internet Backbone Upgrade   | R 585 000   | 6 WEEKS  | CRITICAL | NONE( ENEBLES PROPOSAL 1) |
| NHLS Laboratory integration | R 350 000   | 10 WEEKS | HIGH     | STABLE HER AND NETWORK    |
| Combined TOTAL              | R 1 635 000 |          |          |                           |

**The recommended implementation sequence is: (1) Internet Backbone
Upgrade — as the foundational enabler, (2) Telemedicine Expansion —
which depends on the upgraded bandwidth, and (3) NHLS Laboratory
Integration — which requires a stable EHR and network foundation. All
three proposals may be funded independently or as a combined
programme.**

**Funding Strategy**

Funding options include: Limpopo Provincial Health ICT Budget
allocation, National Department of Health Digital Health grant,
Public-Private Partnership (PPP) with telecom providers for internet
infrastructure, and donor funding from organisations supporting rural
health digitisation (e.g., Gates Foundation, USAID). The combined
investment of ZAR 1,635,000 represents a strategic opportunity to
significantly enhance healthcare access and quality for the 350,000+
residents of the Sekhukhune District.

## PART D- PROJECT PLAN

### Executive Summary

This Project Report provides a comprehensive account of the Sekhukhune
District Hospital IT Infrastructure Project, covering its rationale,
implementation approach, progress to date, outcomes achieved, challenges
encountered, and recommendations for future initiatives. The project was
initiated to transform the hospital from a paper-dependent, digitally
disconnected facility into a modern, connected health institution
capable of delivering efficient, technology-enabled care to the
communities of the Sekhukhune District in Limpopo Province, South
Africa.

The project successfully delivered a campus-wide LAN and Wi-Fi network,
a centralised server infrastructure, an integrated Electronic Health
Records (EHR) system, and a telemedicine platform linking the district
hospital to three primary healthcare clinics. The total project cost was
ZAR 4,680,000 against an approved budget of ZAR 4,850,000, realising a
saving of ZAR 170,000. The project was completed over 26 weeks, within
the planned timeline, with the go-live achieved on schedule.

### PROJECT BACKGROUND AND CONTEXT

**Organisational Context**

Sekhukhune District Hospital is a 320-bed public hospital serving a
predominantly rural population in the Sekhukhune District Municipality,
Limpopo Province. Before this project, the hospital relied on manual
patient records, intermittent internet connectivity through a single
ADSL line, and standalone administrative computers with no centralised
network. The lack of digital infrastructure resulted in delayed
diagnoses, inefficient patient flow management, and limited access to
specialist consultations.

**Problem Statement**

The hospital faced critical IT deficiencies: fragmented patient records
leading to medication errors, inability to access specialist opinions
remotely, slow administrative processes, and non-compliance with the
Protection of Personal Information Act (POPIA) for digital data. The
South African National Department of Health's Digital Health Strategy
(2020-2025) explicitly called for district hospitals to adopt EHR
systems and telemedicine capabilities.

**Project Objectives**

-Deploy a campus-wide structured cabling and Wi-Fi network covering all
clinical and administrative areas

-Install and configure a centralised server infrastructure with adequate
redundancy

-Implement an integrated EHR system for patient records, prescriptions,
and lab results

-Establish a telemedicine platform connecting the hospital to three
feeder clinics

-Train all clinical and administrative staff on new systems

-Achieve POPIA compliance for all digital patient data

### Implementation Approach

**Methodology**

The project employed a hybrid methodology: a predictive (waterfall)
approach for infrastructure components (cabling, hardware, network
deployment) where sequential dependencies existed, and agile sprints for
EHR configuration, telemedicine setup, and user training where iterative
feedback was essential. Each phase concluded with a formal gate review
before proceeding.

**Phases Executed**

| **Phase**                | **Duration**   | **Status**    |
|--------------------------|----------------|---------------|
| **Initiation**           | **2 weeks**    | **Completed** |
| **Planning**             | **4 weeks**    | **Completed** |
| **Execution**            | **16 weeks**   | **Completed** |
| **Monitoring & Control** | **Continuous** | **Completed** |
| **Closure**              | **2 weeks**    | **Completed** |

### Deliverables and Outcomes

**Infrastructure Deliverables**

| **Deliverable**    | **Specification**                       | **Status**                 |
|--------------------|-----------------------------------------|----------------------------|
| Structured cabling | Cat 6A, 280 drops across 12 buildings   | Delivered and certified    |
| Campus Wifi        | 802.11ax, 45 access points              | Delivered and Commissioned |
| Server room        | 3 racks, environmental monitoring, UPS  | Delivered and Operational  |
| Core network       | 10 Gbps backbone, redundant fibre links | Delivered and tested       |
| Firewall and IDS   | Next-gen firewall with IDS/IPS          | Delivered and configured   |

**Application Deliverables**

| **Deliverable**         | **Specification**                             | **Status**                |
|-------------------------|-----------------------------------------------|---------------------------|
| EHR system              | DHIS- based, customised for district hospital | Delivered and operational |
| Telemedicine Platform   | Video Consultation with 3 feeder clinics      | Delivered and Operational |
| Patient portal          | Web based appointment and results access      | Delivered and Operational |
| Admin Management system | Inventory HR and finance module               | Delivered and Operational |

### TRAINING OUTCOMES

A total of 187 staff members completed training across three cohorts:
Clinical staff(94), administrative staff(58) and IT support staff (35).
Post training assessments showed an average competency score of 82%,
exceeding the 75% target.A team of 12 peer champions was established to
provide ongoing first line support.

**BUDGET PERFORMANCE**

| **Category**                       | **Budget(ZAR)**  | **Actual(ZAR)**  | **Variance**                 |
|------------------------------------|------------------|------------------|------------------------------|
| Network Infrastructure             | R 1 200 000      | R 1 150 000      | -R 50 000 (4.2% under)       |
| Server and Hardware                | R 950 000        | R 920 000        | -R 30 000( 3.2% under)       |
| HER software and licensing         | R 1 000 000      | R 1 050 000      | +R 50 000(5% over)           |
| Telemedicine platform              | R 500 000        | R 480 000        | -R 20 000(4% under)          |
| Training and change management     | R 400 00         | R 380 000        | -R 20 000(5% under)          |
| Project Management and contingency | R 800 000        | R 700 000        | -R 100 000(12.5% under)      |
| **TOTAL**                          | **=R 4 850 000** | **=R 4 680 000** | **= -R 170 000(3.5% UNDER)** |

**SCHEDULE PERFORMANCE**

The project was completed within the planned 26 week timeline. The
critical path was maintained throughout with only one minor schedule
deviation. The EHR configuration phased required two additional days for
custom report template development. This was absorbed within float
available in the training phase and did not impact the go live date.

| **Milestone**          | **Planned Date** | **Actual Date** | **Variance** |
|------------------------|------------------|-----------------|--------------|
| Project kick off       | Week 1           | Week 1          | On Schedule  |
| Baseline Plan Approved | Week 6           | Week 6          | On Schedule  |
| Procurement Complete   | Week 10          | Week 11         | On Schedule  |
| Cabling Complete       | Week 14          | Week 14         | On Schedule  |
| Network Live           | Week 17          | Week 17         | On Schedule  |
| EHR Config Complete    | Week 20          | Week 20         | On Schedule  |
| Training Complete      | Week 22          | Week 22         | On Schedule  |
| SIT PASS               | Week 24          | Week 24         | On schedule  |
| GO LIVE                | Week 25          | Week 25         | On Schedule  |
| Project Closure        | Week 26          | Week 26         | On Schedule  |

**Risks and Issues Encountered**

| **Risk/Issue**                                  | **Severity** | **Impact**                                  | **Resolution**                                       |
|-------------------------------------------------|--------------|---------------------------------------------|------------------------------------------------------|
| Vendor delivery delay (Network Medium switches) | Medium       | 1 week delay on procurement milestone       | Activated backup vendor; partial shipment            |
| Staff resistance in radiology department        | High         | Low Training attendance in Week 21          | Appointed departmental champion; reschedule training |
| Power Outage during server installation         | Medium       | 4 Hours lost productivity                   | UPS installed first; generator backup secured        |
| EHR custom report templates exceeded estimate   | Low          | 2- day delay on EHR Config milestone        | Absorbed in training phase float                     |
| Minor data migration inconsistencies            | Medium       | 3 patient records Flagged for manual review | Validation scripts corrected; data remigrated        |

### Lessons Learned

**-** Engage clinical staff as change champions from Day 1 early buy in
significantly reduces resistance during training and go-live

\- Install power backup (UPS/generator) before any equipment deployment
the hospital environment is prone to outages

\- Pre-qualify backup vendors during planning this saved the project
from a critical 3-week delay on switch procurement

\- Allow 15% schedule buffer on EHR customisation configuration effort
consistently exceeded initial estimates

\- Run a trial data migration at least 4 weeks before go-live early
detection of mapping errors prevents last-minute crises

\- Telemedicine adoption exceeded expectations; future projects should
budget for higher concurrent session capacity from day one

### Recommendations

**-** Expand telemedicine to an additional five feeder clinics in the
next financial year, given the strong clinical uptake

-Implement a continuous professional development programme to maintain
and advance staff digital literacy

-Upgrade the internet backbone from 100 Mbps to 500 Mbps to support
growing telemedicine and EHR traffic

-Establish a permanent IT help desk at the hospital with at least two
dedicated support technicians

\- Conduct a POPIA compliance audit within 6 months of go-live to ensure
ongoing data protection adherence

\- Integrate the hospital system with the National Health Laboratory
Service (NHLS) for automated lab result feeds

### Conclusion

The Sekhukhune District Hospital IT Infrastructure Project has
successfully delivered a modern, reliable, and secure IT foundation that
transforms the hospital's ability to provide quality healthcare. The
project was completed on time, under budget, and with strong stakeholder
satisfaction. The lessons learned and recommendations outlined in this
report should inform the next phase of digital health expansion across
the Sekhukhune District and serve as a reference model for similar
projects in other district hospitals within Limpopo Province.

## References

Quilty, D. (2022). *Top 10 healthcare technology trends of 2025*.
\[online\]. Available at:
<https://firstup.io/blog/healthcare-technology-trends> \[Accessed 20
Aug. 2026\].

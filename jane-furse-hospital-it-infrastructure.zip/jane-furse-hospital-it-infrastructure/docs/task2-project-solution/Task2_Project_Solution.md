# Task 2 – Project Solution: New Jane Furse Memorial Hospital IT Infrastructure

## 1. Introduction and design assumptions

This report sets out the detailed solution for connecting the New Jane
Furse Memorial Hospital to a dedicated, secure and sustainable network.
It covers the hardware, the system and application software, the network
setup and the policies and standard operating procedures (SOPs) needed
to run it, all delivered within the 12-month window and the R1,254,000
budget approved in the Project Charter (Task 1).

**In plain terms:** the hospital is 1 km from the municipal network. We
extend that network to the hospital by splicing into the municipality's
existing fiber, connect it to the internet through Openserve (the only
carrier in the district), and then build everything inside the hospital
that a modern, secure network needs. Just as important, we leave behind
trained local staff and written procedures so the hospital can run it
without us.

### 1.1 Starting point (from the scenario)

| Item                          | Current situation                                                                                    |
|-------------------------------|------------------------------------------------------------------------------------------------------|
| Hospital                      | New Jane Furse Memorial Hospital, the largest public hospital in Sekhukhune District, Limpopo        |
| Staff                         | About 600 (medical, administrative and contractors)                                                  |
| Patients                      | About 100 per day                                                                                    |
| Layout                        | About 20 wards and 5 offices                                                                         |
| Distance to municipal network | 1 km                                                                                                 |
| Carrier                       | Openserve (only carrier available)                                                                   |
| Computers and printers        | 15 very old computers and 3 printers                                                                 |
| ICT staff                     | 3 support staff                                                                                      |
| Security                      | Missing: no proper firewall, intrusion detection or endpoint protection                              |
| Main concerns                 | Data storage, missing patient files, suppliers needing network access, sustainability after handover |

### 1.2 Design assumptions

The scenario leaves some details open, so these assumptions are made and
should be read together with the Project Charter.

1.  The municipality formally agrees (in writing) to the fiber splice
    and signs a service level agreement (SLA) with the hospital.

2.  Existing ducting or poles can be used for the 1 km fiber route. New
    civil works such as trenching are out of scope, as the Charter
    states.

3.  The hospital's existing management systems (operations, finance,
    supply chain) are kept. The project provides the network, servers,
    security and access to them. It does not replace them.

4.  The hospital's electricity supply can carry the extra IT load, with
    UPS (battery) backup and a generator-ready design.

5.  Prices are planning estimates in South African rand, excluding VAT,
    and are confirmed through the public-sector tender process.

6.  The 600 staff do not each get a computer. The 25 new workstations
    and 4 mobile carts are shared at wards, nurses' stations and
    offices, and staff also reach systems through Wi-Fi. This is a
    phase-one design that can grow.

7.  Ongoing running costs (Openserve line rental, licence renewals,
    support retainer) are paid from the hospital's operating budget
    after handover. Section 8 shows these costs so they can be budgeted
    for.

### 1.3 Alignment with Task 1

This report uses the same 12-month timeline, five objective pillars
(connectivity, infrastructure modernisation, cybersecurity, operational
efficiency, capacity building) and budget categories as the Project
Charter. The staff count is updated to 600 and the hospital name to *New
Jane Furse Memorial Hospital*, as in the scenario.

## 2. Requirements analysis

The hospital needs seven things, and every item in this report traces
back to one of them. Requirement codes (R1 to R7) are used in later
tables so a marker can see why each item was chosen.

| Code | Requirement                                           | Why it is needed                                                                                                          | Where it is solved                                                  |
|------|-------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------|
| R1   | Fast, dedicated and reliable internet                 | A shared or commercial link is slow and unpredictable. The Charter targets at least 100 Mbps symmetrical and 99.5% uptime | Sections 3 and 5 (fiber, router, Openserve link, LTE backup)        |
| R2   | Modern computers and printers                         | 15 very old computers and 3 printers cannot serve 600 staff and about 100 patients a day                                  | Section 3.3 (workstations, printers, carts)                         |
| R3   | Secure network and data                               | No firewall, intrusion detection or endpoint protection. Patient data is sensitive under POPIA                            | Sections 3.2, 4 and 5.6 (firewall, endpoint security, segmentation) |
| R4   | Safe central data storage and backup                  | Patient files go missing and storage is a concern                                                                         | Sections 3.4 and 4.4 (servers, NAS, cloud backup)                   |
| R5   | Working business systems                              | Operations, finance and supply chain software must run on the new network                                                 | Section 4 (system and application software)                         |
| R6   | Safe supplier access                                  | Suppliers use the hospital network and could become a way in for attackers                                                | Sections 5.5 and 6.8 (supplier VLAN and policy)                     |
| R7   | A team that can run it, and a plan to keep it running | Only 3 ICT staff, and the project must be self-sustaining                                                                 | Sections 6, 7 and 8 (SOPs, training, sustainability)                |

### 2.1 Sizing the network

A simple capacity check shows why 100 Mbps symmetrical is the right
starting size.

| Factor                              | Estimate         | Reasoning                                                     |
|-------------------------------------|------------------|---------------------------------------------------------------|
| Staff online at peak                | About 150 of 600 | Shift work: roughly a quarter of staff are active at one time |
| Average demand per active user      | About 0.5 Mbps   | Mostly records, email and web, with light video               |
| Wi-Fi, patient and supplier traffic | About 15 Mbps    | Guest Wi-Fi is rate-limited                                   |
| Total expected peak                 | About 90 Mbps    | Close to the 100 Mbps target                                  |

The fiber and switches are bought at 1 Gbps or higher, so only the
Openserve service needs upgrading when demand grows (for example to 200
Mbps) with no new hardware. The 500 Mbps upgrade in Task 1, Proposal 2
builds on exactly this.

### 2.2 Standards and legal requirements

- **POPIA** (Protection of Personal Information Act) for all patient and
  staff data.

- **ISO/IEC 27001** as the model for the information security policies
  in Section 6.

- **SANS 10142-1** for electrical work and **SANS 10173 / ISO/IEC
  11801** style structured cabling practice.

- **Public-sector procurement rules** (PFMA and the Limpopo Provincial
  Supply Chain Management policy), including three quotations above
  R500,000 as set in the Charter.

- **National Health Normative Standards Framework (HNSF)** for health
  information interoperability.

## 3. Hardware requirements and solution

The hardware and installation items cost R940,000, in line with the
Project Charter budget. Every list below is a bill of materials (BOM)
with a specification, quantity and estimated cost. Spares are built into
the quantities, so the ICT team can swap a failed unit straight away
(see the replacement SOP in Section 6.7).

### 3.1 Hardware budget summary

| Category                                      | Estimate (ZAR) | Section |
|-----------------------------------------------|----------------|---------|
| Fiber infrastructure and splicing             | R 180 000      | 3.2     |
| Network hardware (core, security, Wi-Fi, UPS) | R 250 000      | 3.3     |
| End-user devices                              | R 320 000      | 3.4     |
| Servers and storage                           | R 190 000      | 3.5     |
| **Subtotal hardware and installation**        | **R 940 000**  |         |

Software (R140,000), training (R60,000) and contingency (R114,000)
complete the R1,254,000 total and are covered in Sections 4, 7 and 8.

### 3.2 Fiber link: municipality to hospital (R1: connectivity)

A fiber-optic cable carries data as light, so it is fast, does not pick
up electrical interference and works over distances far longer than 1
km. Single-mode fiber is chosen because it will still be usable when
speeds increase in future.

| Item                                   | Specification                                                                                               | Qty   | Estimate (ZAR) |
|----------------------------------------|-------------------------------------------------------------------------------------------------------------|-------|----------------|
| Fiber cable                            | 24-core single-mode (OS2), armoured, outdoor rated                                                          | 1 km  | R 45 000       |
| Splice and termination                 | Fusion splices at the municipal splice point and at the hospital, splice closures, fiber patch panels (ODF) | 1 lot | R 35 000       |
| Route installation                     | Pulling through existing ducts or aerial fixing on existing poles, route markers, labour                    | 1 km  | R 70 000       |
| Testing and certification              | OTDR test report and light-loss test on every core                                                          | 1 lot | R 10 000       |
| Wayleave, permits and splice enclosure | Municipal permission paperwork, lockable splice-point cabinet                                               | 1 lot | R 20 000       |
| **Total**                              |                                                                                                             |       | **R 180 000**  |

We lay 24 cores although only 2 are needed now. One pair carries the
live link, one pair is a spare, and the rest allow future expansion (for
example, linking clinics) without digging again.

### 3.3 Network and security hardware (R1, R3)

| Item                            | Specification                                                                                                          | Qty   | Unit (ZAR) | Total (ZAR)   |
|---------------------------------|------------------------------------------------------------------------------------------------------------------------|-------|------------|---------------|
| Core layer-3 switch             | 24 x 1 GbE, 4 x 10G SFP+, stackable, redundant power supply                                                            | 2     | R 22 000   | R 44 000      |
| Access switch (PoE+)            | 24 x 1 GbE PoE+, 4 x SFP uplinks, managed (7 deployed + 1 spare)                                                       | 8     | R 5 000    | R 40 000      |
| Edge router                     | Dual WAN (fiber and LTE), supports QoS and VPN                                                                         | 1     | R 18 000   | R 18 000      |
| Next-generation firewall (NGFW) | Intrusion prevention, web filtering, VPN, 1 Gbps throughput with security enabled                                      | 1     | R 42 000   | R 42 000      |
| Wi-Fi 6 access point            | Ceiling mounted, PoE, WPA3-Enterprise (18 deployed + 2 spare)                                                          | 20    | R 2 300    | R 46 000      |
| Cabinet UPS                     | 1 kVA line-interactive, rack mount, for each ward comms cabinet                                                        | 6     | R 5 500    | R 33 000      |
| Passive and misc. materials     | Cat6 cable and patch panels for offices and nurses' stations, patch leads, SFP+ modules, 4G/LTE failover modem, labels | 1 lot | R 27 000   | R 27 000      |
| **Total**                       |                                                                                                                        |       |            | **R 250 000** |

Why two core switches? If one fails, the other keeps the hospital
working. Why a separate router and firewall? The router moves traffic,
and the firewall inspects it. Keeping them separate means each can be
replaced or upgraded on its own.

**Wi-Fi coverage:** 18 active access points cover the 20 wards and 5
offices (roughly one per ward cluster or corridor, plus one per office
block). A wireless site survey in Month 2 fixes the final positions
before anything is mounted.

### 3.4 End-user devices (R2)

| Item                            | Specification                                                                                                                   | Qty | Unit (ZAR) | Total (ZAR)   |
|---------------------------------|---------------------------------------------------------------------------------------------------------------------------------|-----|------------|---------------|
| Desktop workstation             | Core i5 or equivalent, 16 GB RAM, 512 GB SSD, 24-inch monitor, Windows 11 Pro, TPM 2.0, 3-year warranty (23 deployed + 2 spare) | 25  | R 8 500    | R 212 500     |
| Networked multifunction printer | A4 mono laser, duplex, print/scan/copy, network and badge release (7 deployed + 1 spare)                                        | 8   | R 6 500    | R 52 000      |
| Mobile workstation cart         | Height-adjustable cart with battery, barcode scanner and all-in-one PC for ward rounds                                          | 4   | R 13 875   | R 55 500      |
| **Total**                       |                                                                                                                                 |     |            | **R 320 000** |

The 15 old computers are wiped securely (see the data-sanitisation step
in Section 6.7) and then donated or disposed of through the hospital's
asset process. Their data is first migrated to the new storage.

### 3.5 Servers, storage and the server room (R4)

| Item                           | Specification                                                                            | Qty | Unit (ZAR) | Total (ZAR)   |
|--------------------------------|------------------------------------------------------------------------------------------|-----|------------|---------------|
| Rack server                    | 2U, 8-core CPU, 64 GB RAM, 4 x 960 GB SSD in RAID 10, dual power, remote management card | 2   | R 45 000   | R 90 000      |
| Network-attached storage (NAS) | 4 x 8 TB disks in RAID 5 (about 24 TB usable), for files and local backup                | 1   | R 35 000   | R 35 000      |
| Cloud backup subscription      | Encrypted off-site backup, South African data center, 12 months                          | 1   | R 30 000   | R 30 000      |
| 12U server cabinet             | Lockable, with cable management and power distribution                                   | 1   | R 10 000   | R 10 000      |
| Server-room UPS                | 3 kVA online double-conversion with network card                                         | 1   | R 25 000   | R 25 000      |
| **Total**                      |                                                                                          |     |            | **R 190 000** |

Two servers share the work (virtualisation, Section 4.2). If one fails,
the other can run the critical services while the failed one is
repaired. **Assumption:** the existing server or comms room has working
air conditioning. If not, a split air-conditioner is funded from the
contingency.

### 3.6 Power protection and the ICT toolkit

Power cuts are a known risk in the district, so power protection is
built in rather than added later:

- Every comms cabinet is on a UPS, and the server room has a larger
  online UPS (items above).

- The electrical design is generator-ready, with a changeover socket so
  the hospital's generator can feed the server room.

- SANS 10142-1 compliant electrical work is done by a registered
  electrician with a certificate of compliance.

- A basic toolkit for the 3 ICT staff (fiber cleaner and inspection
  scope, cable tester, crimper, laptop console cable, label printer) is
  funded from the contingency (about R12,000).

## 4. System and application software

The software budget is R140,000. Where a free, well-supported
open-source tool does the job (monitoring, ticketing), it is used so the
hospital is not locked into yearly fees it cannot afford. Where the
hospital needs vendor support (operating systems, security, backup),
commercial products are used.

### 4.1 Software budget summary

| Software                                                         | Purpose                                                         | Licence basis                | Estimate (ZAR) |
|------------------------------------------------------------------|-----------------------------------------------------------------|------------------------------|----------------|
| Windows Server Standard, plus user/device access licences (CALs) | Runs the servers and the central user directory                 | 2 hosts + 50 CALs, perpetual | R 38 000       |
| Office productivity suite                                        | Documents, email client and spreadsheets on the 25 new devices  | 25 perpetual licences        | R 20 000       |
| Endpoint protection (EDR)                                        | Anti-malware and threat detection on servers and workstations   | About 40 endpoints, 1 year   | R 22 000       |
| Firewall security subscription                                   | Intrusion prevention, anti-virus gateway, web filtering updates | 1 year                       | R 30 000       |
| Backup software                                                  | Scheduled, encrypted backups of servers to NAS and cloud        | 2 hosts, 1 year              | R 20 000       |
| Network monitoring and support                                   | Zabbix (open source) with paid support for set-up               | 1 lot                        | R 10 000       |
| **Total**                                                        |                                                                 |                              | **R 140 000**  |

Windows 11 Pro comes with the new workstations. Ticketing (GLPI) and the
captive Wi-Fi portal are open source and free.

### 4.2 Server platform (R4, R5)

Both servers run **Hyper-V virtualisation**. Virtualisation means one
physical server hosts several "virtual servers", each doing one job. It
saves hardware, makes backups easier, and lets a virtual server be
restarted on the second host if the first one fails.

| Virtual server | Role                                       | Host   | Notes                                                                          |
|----------------|--------------------------------------------|--------|--------------------------------------------------------------------------------|
| DC1            | Active Directory, DNS and DHCP (primary)   | Host A | Central user accounts and passwords                                            |
| DC2            | Active Directory, DNS and DHCP (secondary) | Host B | Keeps logins working if DC1 fails                                              |
| FILE1          | File server                                | Host A | Department shares and the central patient-file index, with permissions by role |
| PRINT1         | Print server                               | Host B | Queue management and secure "badge release" printing                           |
| APP1           | Application gateway                        | Host A | Controlled access to the existing operations, finance and supply-chain systems |
| WSUS1          | Update server                              | Host B | Patches approved by ICT before staff computers receive them                    |
| MON1           | Zabbix monitoring and GLPI ticketing       | Host B | Alerts and help-desk records                                                   |
| BKP1           | Backup server                              | Host A | Runs the backup jobs (Section 4.4)                                             |

Each host is sized to run every virtual server on its own, which is how
the continuity plan (Section 6.1) survives the loss of one host.

### 4.3 Workstation and user software (R2)

- **Standard image:** one tested Windows 11 Pro build, with the office
  suite, endpoint protection, PDF reader and browser pre-installed. A
  new or replacement PC is imaged in about an hour, which makes hardware
  replacement fast.

- **Domain join and Group Policy:** every PC joins the central
  directory. Policies enforce screen lock after 5 minutes, password
  rules, disabled USB storage (except approved devices) and removal of
  local admin rights.

- **Disk encryption:** BitLocker is switched on for all devices, with
  recovery keys stored in Active Directory.

- **Role-based accounts:** each person has their own login, and
  permissions follow their job (doctor, nurse, finance officer, ICT
  admin). Shared logins are not allowed.

### 4.4 Data storage and backup software (R4)

The concern about data storage and missing patient files is answered by
one rule: **no important data lives only on a single PC.**

| Backup layer                         | What it protects                                            | Frequency                                | Retention                                   | Location                         |
|--------------------------------------|-------------------------------------------------------------|------------------------------------------|---------------------------------------------|----------------------------------|
| Layer 1: file server with versioning | Accidentally deleted or changed files                       | Continuous (shadow copies every 4 hours) | 30 days                                     | Hosts and NAS                    |
| Layer 2: local backup                | Full server images and file shares                          | Nightly (incremental), weekly (full)     | 4 weeks                                     | NAS                              |
| Layer 3: off-site cloud backup       | Everything critical, if the building or server room is lost | Nightly, encrypted                       | 90 days, with monthly copies kept 12 months | Cloud, South African data center |

This is the 3-2-1 rule: 3 copies of the data, on 2 different kinds of
storage, with 1 copy off-site. Restore tests are done quarterly (SOP in
Section 6.2).

### 4.5 Security software (R3)

| Control                           | Tool                                                 | What it does in plain terms                                   |
|-----------------------------------|------------------------------------------------------|---------------------------------------------------------------|
| Firewall and intrusion prevention | Next-generation firewall with subscription           | Blocks known attacks and suspicious traffic at the front door |
| Endpoint detection and response   | EDR agent on every PC and server                     | Spots viruses and ransomware on a computer and can isolate it |
| Patch management                  | WSUS plus firmware schedule                          | Closes known security holes in Windows and network devices    |
| Secure Wi-Fi                      | WPA3-Enterprise with each user's own login           | Only authorised staff reach the staff network                 |
| Network monitoring                | Zabbix, plus firewall logs                           | Alerts the ICT team when a link, device or disk is in trouble |
| Central logging                   | Firewall and server logs on MON1, kept 12 months     | Evidence for investigating incidents and POPIA breaches       |
| Multi-factor authentication (MFA) | MFA for ICT admins and for remote or supplier access | A stolen password alone is not enough                         |

### 4.6 Business applications (R5)

The hospital already uses software for **operations, finance and supply
chain**, and the project connects it to the new network rather than
replacing it. The approach is:

1.  **Inventory:** list every application, its owner, its server
    location and who uses it (Month 2).

2.  **Connect:** those systems that run on provincial or national
    servers are reached through the new fiber link and the firewall,
    with only the required ports opened. Systems that must run locally
    are moved onto the new servers.

3.  **Move the data:** a trial migration is run first, followed by
    checks, and then the final migration with a rollback plan (Section
    7.4). Lessons learned in Task 1 recommend running the trial at least
    4 weeks before go-live.

4.  **Missing patient files:** existing electronic and scanned records
    are consolidated into the central file server with a clear folder
    structure and role-based access. Paper-file scanning is a
    recommended next phase, not part of this budget.

5.  **User acceptance:** each department signs off that its system works
    on the new network (UAT, Section 7.4).

### 4.7 ICT management tools

- **Zabbix:** a dashboard showing the state of the fiber link, firewall,
  switches, APs, servers and disk space, with SMS or e-mail alerts to
  the ICT staff.

- **GLPI help desk:** every fault is logged as a ticket with an owner
  and a time stamp. This gives the hospital evidence for planning and
  for the vendor support retainer.

- **Asset register:** every device is recorded with serial number,
  location, warranty date and owner, and it is updated by the
  replacement SOP.

## 5. Network setup

The network is built as a **star design**: one core in the server room,
six ward cabinets connected back to it, and a single, firewalled exit to
the internet. Traffic is split into separate virtual networks (VLANs),
so a problem or an attack in one area, such as guest Wi-Fi or a supplier
laptop, cannot spread into patient systems.

### 5.1 Design principles

1.  **Dedicated:** the hospital's traffic does not compete with other
    customers on the link.

2.  **Layered:** router, firewall, segmentation, endpoint security and
    monitoring each protect on their own.

3.  **No single point of failure** for the critical path: two core
    switches, two servers, UPS everywhere, LTE backup for the internet
    link.

4.  **Simple enough for three people to run:** standard device models,
    standard configurations, clear naming and written procedures.

5.  **Ready to grow:** spare fiber cores, spare switch ports and 10G
    uplinks.

### 5.2 Network topology (end to end)

Traffic from a ward device goes through the following path to the
internet:

Ward device \> Ward cabinet switch (access) \> Core switches (server
room) \> Firewall \> Edge router \> Hospital fiber (1 km) \> Municipal
splice point and network \> Openserve \> Internet

A backup path runs from the router through the **LTE modem** to the
mobile network. It carries only critical traffic if the fiber fails.

### 5.3 Fiber splice and Openserve connection (R1)

The central idea of the scenario: instead of buying a separate line from
the carrier to the hospital, the project **splices into the
municipality's existing network and extends it 1 km to the hospital**.
The municipality's network already reaches Openserve, so the hospital
borrows a high-quality path instead of paying for a new one.

| Step | Action                                                                                                                         | Owner                                                    | When         |
|------|--------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------|--------------|
| 1    | Sign the memorandum of understanding and SLA with the municipality, including the right to splice and use the route (wayleave) | Hospital CEO and Municipal IT Director                   | Month 1 to 2 |
| 2    | Site survey: walk the 1 km route, identify ducts, poles, splice point and hospital entry                                       | Network engineer and municipal technician                | Month 2      |
| 3    | Order a dedicated, symmetrical Openserve service delivered at the municipal node (product and price confirmed at tender)       | Project manager and procurement officer                  | Month 2      |
| 4    | Install the 24-core fiber along the surveyed route                                                                             | Cabling contractor                                       | Month 5 to 6 |
| 5    | Fusion-splice into the municipal closure and terminate at the hospital ODF                                                     | Certified splicing contractor with municipal supervision | Month 6      |
| 6    | Test every core with OTDR and issue the certification report                                                                   | Contractor and network engineer                          | Month 6      |
| 7    | Light up the link, configure the edge router and test throughput                                                               | Network engineer                                         | Month 7      |
| 8    | Network Live milestone: acceptance test signed                                                                                 | Hospital CEO and Municipal IT Director                   | Month 7      |

**Service targets** agreed with the municipality and Openserve (taken
from the Charter success criteria):

| Item                                  | Target                                                                          |
|---------------------------------------|---------------------------------------------------------------------------------|
| Bandwidth                             | At least 100 Mbps, symmetrical (same speed up and down), upgradable to 500 Mbps |
| Availability                          | 99.5% per month (about 3.6 hours of downtime allowed)                           |
| Fiber fault response                  | Technician on site within 4 hours for a fiber cut, repair within 24 hours       |
| Planned maintenance                   | Notified 5 working days ahead and done outside 06:00 to 20:00 where possible    |
| Latency to the provincial data center | Under 20 ms                                                                     |
| Backup link                           | 4G/LTE failover switches over in under 60 seconds                               |

### 5.4 Cabinet plan

| Cabinet | Location             | Serves                                                                       | Switch and power                                            |
|---------|----------------------|------------------------------------------------------------------------------|-------------------------------------------------------------|
| SR      | Server room          | Core, firewall, router, servers, NAS, plus 1 access switch for admin offices | 2 core switches and 1 access switch on the 3 kVA online UPS |
| CAB-A   | Ward block A         | Wards 1 to 4                                                                 | 1 access switch and 1 kVA UPS                               |
| CAB-B   | Ward block B         | Wards 5 to 8                                                                 | 1 access switch and 1 kVA UPS                               |
| CAB-C   | Ward block C         | Wards 9 to 12                                                                | 1 access switch and 1 kVA UPS                               |
| CAB-D   | Ward block D         | Wards 13 to 16                                                               | 1 access switch and 1 kVA UPS                               |
| CAB-E   | Ward block E         | Wards 17 to 20                                                               | 1 access switch and 1 kVA UPS                               |
| CAB-F   | Administration block | The 5 offices, finance and supply chain                                      | 1 access switch and 1 kVA UPS                               |

The exact ward-to-cabinet split is confirmed in the Month 2 site survey.
Each ward cabinet connects back to the core switches with a 1 Gbps fiber
or Cat6 uplink, depending on distance (over 90 m uses fiber). One access
switch is held as a spare.

### 5.5 VLAN and IP addressing plan

The network uses private addresses in the 10.10.0.0/16 range. Each
department type gets its own VLAN, with the first address (.1) being the
gateway.

| VLAN | Name           | Subnet        | Used by                                             | DHCP               |
|------|----------------|---------------|-----------------------------------------------------|--------------------|
| 10   | Management     | 10.10.10.0/24 | Switch, AP, firewall and server management          | Static only        |
| 20   | Clinical       | 10.10.20.0/23 | Ward workstations, carts, clinical staff            | Yes                |
| 30   | Administration | 10.10.30.0/24 | Offices, finance, supply chain                      | Yes                |
| 40   | Servers        | 10.10.40.0/24 | Hosts, virtual servers, NAS                         | Static only        |
| 50   | Printers       | 10.10.50.0/24 | Network printers                                    | Reserved addresses |
| 60   | Staff Wi-Fi    | 10.10.60.0/23 | Staff phones, tablets and laptops (WPA3-Enterprise) | Yes                |
| 70   | Guest Wi-Fi    | 10.10.70.0/23 | Patients and visitors (isolated, rate-limited)      | Yes                |
| 80   | Supplier       | 10.10.80.0/24 | Approved supplier devices and VPN users             | Yes                |
| 99   | Unused ports   | None          | Parked unused switch ports (disabled)               | None               |

The firewall also has three zones: **Inside** (VLANs 10 to 60),
**Guest** (VLAN 70), and **Supplier/DMZ** (VLAN 80). The outside
connection uses a public static address supplied through Openserve.

### 5.6 Firewall rule set (R3, R6)

The default rule is **deny everything and log it**. Only the traffic
below is allowed.

| No. | From                                  | To                              | Allowed                                                                       | Reason                                     |
|-----|---------------------------------------|---------------------------------|-------------------------------------------------------------------------------|--------------------------------------------|
| 1   | Clinical (20) and Administration (30) | Servers (40)                    | Directory login, file sharing, print, application ports only                  | Daily work                                 |
| 2   | Staff and servers                     | Internet                        | Web (80, 443), DNS and e-mail through filtering                               | Browsing with web filtering and anti-virus |
| 3   | Staff Wi-Fi (60)                      | Servers (40)                    | Same as rule 1                                                                | Staff using their own devices for work     |
| 4   | Guest Wi-Fi (70)                      | Internet only                   | Web, rate-limited to 10 Mbps in total                                         | Keeps guests away from hospital systems    |
| 5   | Supplier (80)                         | One application gateway on APP1 | HTTPS to specified addresses only, with MFA                                   | Suppliers see only what they need          |
| 6   | ICT admin workstations                | Management (10)                 | SSH, HTTPS, SNMPv3                                                            | Only ICT can manage devices                |
| 7   | Print server                          | Printers (50)                   | Print protocols only                                                          | Users never talk directly to printers      |
| 8   | Servers                               | Cloud backup address            | Encrypted backup traffic                                                      | Off-site backup                            |
| 9   | Internet                              | Inside                          | Denied. Only the VPN service for ICT and approved suppliers is open, with MFA | Blocks outside attackers                   |
| 10  | Any                                   | Any                             | **Deny and log**                                                              | Default                                    |

### 5.7 Wi-Fi design (R1, R3)

| SSID              | Who                                | Security                                                             | Network |
|-------------------|------------------------------------|----------------------------------------------------------------------|---------|
| Hospital-Staff    | Employees and approved contractors | WPA3-Enterprise (own username and password)                          | VLAN 60 |
| Hospital-Guest    | Patients and visitors              | WPA2/WPA3 with a captive portal and accepted terms, isolated clients | VLAN 70 |
| Hospital-Supplier | Approved supplier devices only     | WPA3-Enterprise with device approval                                 | VLAN 80 |

The access points have a controller or cloud management portal for
central updates. Radio channels are planned in the site survey to avoid
interference, and the 5 GHz band is preferred in wards.

### 5.8 Quality of service (QoS)

When the link is busy, clinical traffic goes first. This was an
important lesson in Task 1 (telemedicine growth).

| Priority    | Traffic                                                                         | Treatment                    |
|-------------|---------------------------------------------------------------------------------|------------------------------|
| 1 (highest) | Patient records and clinical applications, voice and video (telemedicine-ready) | Guaranteed share of the link |
| 2           | Finance, supply chain, e-mail, software updates                                 | Normal                       |
| 3           | General web browsing                                                            | Best effort                  |
| 4 (lowest)  | Guest Wi-Fi, streaming and downloads                                            | Rate-limited and capped      |

### 5.9 Core services and standard device settings

- **DNS, DHCP and time (NTP):** provided by DC1 and DC2 for resilience.
  Time is synchronised across the whole network so log files line up
  during investigations.

- **Routing:** static default route towards the Openserve service, with
  a lower-priority route through the LTE modem. A routing protocol is
  unnecessary at this size.

- **Switches:** Spanning Tree Protocol for loop protection, port
  security on user ports, unused ports shut down and parked in VLAN 99,
  802.1X where supported, and a banner warning of authorised use only.

- **Management:** SSH only (Telnet disabled), SNMPv3, unique admin
  accounts, and configuration backups stored on MON1 after every change.

- **Naming:** devices are named by role and location, for example
  sw-cab-a-01, ap-ward-07, srv-host-a, so anyone on the team can find
  them.

- **Labelling:** every cable and every port is labelled at both ends,
  and a one-page patch schedule is kept in every cabinet.

### 5.10 Supplier access (R6)

Suppliers are important but they are also a recognised route for
attackers. Each supplier gets: a named account, a signed access
agreement, access only through VLAN 80 or the VPN, MFA, a time limit
(for example 90 days, then re-approval) and a log of what they accessed.
The full policy is in Section 6.8.

## 6. Policies and standard operating procedures (SOPs)

Equipment alone does not make a network safe or sustainable. Written
rules do. A **policy** says what must happen and why. An **SOP** says
exactly how, step by step, so any trained team member can do it, even on
a bad day. The set below is written to be short enough that three people
will actually use it.

| No.  | Document                                       | Type   | Owner                                       | Review                                 |
|------|------------------------------------------------|--------|---------------------------------------------|----------------------------------------|
| 6.1  | Business continuity and disaster recovery plan | Plan   | ICT Manager                                 | Every 6 months, and after any incident |
| 6.2  | Backup and restore                             | SOP    | ICT Manager                                 | Yearly                                 |
| 6.3  | Information security and access control        | Policy | Hospital CEO (approves), ICT Manager (owns) | Yearly                                 |
| 6.4  | Incident response                              | SOP    | ICT Manager                                 | Every 6 months                         |
| 6.5  | Patching and change management                 | SOP    | ICT Manager and Change Board                | Yearly                                 |
| 6.6  | Acceptable use                                 | Policy | Hospital CEO                                | Yearly                                 |
| 6.7  | Hardware replacement and troubleshooting       | SOP    | ICT Support staff                           | Yearly                                 |
| 6.8  | Supplier and third-party access                | Policy | ICT Manager                                 | Yearly                                 |
| 6.9  | Data protection (POPIA)                        | Policy | Information Officer                         | Yearly                                 |
| 6.10 | Power failure                                  | SOP    | ICT Manager and Facilities                  | Yearly                                 |

### 6.1 Business continuity and disaster recovery plan

**Purpose.** To keep patient care running, and restore IT services
within agreed times, when something goes seriously wrong.

**Scope.** All systems, network equipment, data and people described in
this report.

**Key terms.** *RTO* (recovery time objective) is the longest time a
service may be down. *RPO* (recovery point objective) is the most data,
measured in time, that the hospital can afford to lose.

#### Business impact analysis

| Service                                   | Why it matters                             | Priority | RTO                                                | RPO            |
|-------------------------------------------|--------------------------------------------|----------|----------------------------------------------------|----------------|
| Core network and ward connectivity        | Everything depends on it                   | 1        | 2 hours                                            | Not applicable |
| Directory and login (DC1, DC2)            | Nobody can log in without it               | 1        | 2 hours                                            | 24 hours       |
| Patient records and clinical applications | Direct effect on patient safety            | 1        | 4 hours                                            | 4 hours        |
| Internet link (fiber)                     | Needed for provincial and national systems | 1        | 60 seconds to LTE backup, 24 hours to repair fiber | Not applicable |
| File server and printing                  | Daily work and printing of prescriptions   | 2        | 8 hours                                            | 4 hours        |
| Finance and supply chain                  | Payments and stock                         | 2        | 24 hours                                           | 24 hours       |
| Supplier access                           | Deliveries and support                     | 3        | 48 hours                                           | 24 hours       |
| Guest Wi-Fi                               | Comfort only                               | 4        | 72 hours                                           | Not applicable |

#### Scenarios and response

| Scenario                                | First response                                                                               | Recovery                                                                                                                            |
|-----------------------------------------|----------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------|
| Fiber cut or Openserve outage           | Router fails over to LTE automatically. ICT logs a fault with the municipality and Openserve | Municipality or Openserve repairs the fiber within 24 hours. Return to fiber and check                                              |
| Power failure                           | UPS carries the equipment. ICT confirms generator start (SOP 6.10)                           | If outage exceeds UPS time, shut servers down gracefully and restart when power returns                                             |
| One server host fails                   | Virtual servers restart on the second host (hosts are each sized for the whole load)         | Repair or replace the failed host under warranty                                                                                    |
| Core or access switch fails             | Swap in the spare switch with the saved configuration (SOP 6.7)                              | Repair or replace the faulty unit                                                                                                   |
| Ransomware or cyber attack              | Isolate infected computers, disconnect affected network segment, follow SOP 6.4              | Restore from clean backups after the threat is removed                                                                              |
| Fire, flood or theft in the server room | Evacuate and make the area safe. The CEO declares a disaster                                 | Use the off-site cloud backup to rebuild on replacement hardware. Order replacement equipment under the emergency procurement rules |
| Loss of key ICT staff member            | Cross-trained colleague takes over using documented procedures                               | Vendor support retainer covers gaps                                                                                                 |

#### Roles during a disaster

| Role                          | Person                                             | Duty                                                        |
|-------------------------------|----------------------------------------------------|-------------------------------------------------------------|
| Disaster declarer             | Hospital CEO                                       | Declares and ends the disaster, approves emergency spending |
| Continuity coordinator        | ICT Manager                                        | Leads recovery, decides the order of restoration            |
| Network and security lead     | ICT Support staff 1                                | Network, firewall, link                                     |
| Server and data lead          | ICT Support staff 2                                | Servers, backups, restores                                  |
| End-user lead                 | ICT Support staff 3                                | Workstations, printers, wards                               |
| Clinical liaison              | Nursing services manager                           | Tells the wards what works and what does not                |
| Municipal and carrier contact | Municipal IT Director and Openserve representative | Fiber and link restoration                                  |

#### Activation steps

1.  **Detect:** monitoring alarm, ward call or ticket reports an outage.

2.  **Assess (within 30 minutes):** the ICT Manager decides whether it
    is an ordinary fault or a disaster.

3.  **Declare:** the CEO is told, and declares a disaster if RTOs will
    be missed. A call-out list (names and phone numbers, printed and
    held off-line) is used.

4.  **Switch to manual procedures:** wards use paper downtime forms for
    admissions, prescriptions and results. Each form is back-captured
    into the system afterwards.

5.  **Recover** in priority order (1 to 4 in the table above).

6.  **Communicate** every 2 hours to ward managers, and to the CEO every
    4 hours.

7.  **Verify:** test the restored services with a ward representative
    before returning to normal.

8.  **Review:** write an incident report within 5 working days and
    update this plan.

#### Testing the plan

| Test                                                                               | Frequency      | Pass mark                                   |
|------------------------------------------------------------------------------------|----------------|---------------------------------------------|
| Failover to LTE link                                                               | Every 3 months | Switches in under 60 seconds                |
| Restore a file and a virtual server from backup                                    | Every 3 months | Restored and working within the RTO         |
| Move virtual servers to the other host                                             | Every 6 months | All critical services running within 1 hour |
| Tabletop exercise (talk-through of a scenario) with ICT, ward and management staff | Every 6 months | Everyone knows their role                   |
| Paper downtime procedure drill on one ward                                         | Yearly         | Forms completed and back-captured correctly |

### 6.2 Backup and restore SOP

**Purpose:** make sure data can always be restored. **Owner:** ICT
Support staff 2, supervised by the ICT Manager.

| Step                                                                                | Daily | Weekly         | Monthly | Quarterly |
|-------------------------------------------------------------------------------------|-------|----------------|---------|-----------|
| Check last night's backup report in the dashboard and fix any failures the same day | Yes   |                |         |           |
| Run the full backup of all virtual servers to the NAS                               |       | Yes (Saturday) |         |           |
| Confirm the cloud copy is complete and the size is as expected                      |       | Yes            |         |           |
| Keep the monthly copy for 12 months                                                 |       |                | Yes     |           |
| **Restore test:** restore a sample file and one virtual server, record the time     |       |                |         | Yes       |

**Restore procedure:**

1.  Log a ticket with the reason for the restore, the item and the date
    wanted.

2.  Get approval from the data owner (head of the department).

3.  Restore to a **separate location first**, check it, then copy it
    into place.

4.  Record the result and the time taken in the ticket and close it.

Backup media and cloud keys are held by two people. Backup encryption
keys are also kept in a sealed envelope in the hospital safe.

### 6.3 Information security and access control policy

**Principle:** each person gets the least access needed to do the job,
and every action can be traced to a person.

- **Accounts:** one account per person. No shared or generic accounts.
  Accounts are created only on a signed request from the line manager
  and the HR department.

- **Passwords:** at least 12 characters, changed when compromised and
  not reused. MFA for ICT administrators and for all remote or supplier
  access.

- **Starters and leavers:** access is created on the first day. HR
  notifies ICT on the day someone resigns, and the account is disabled
  on the last working day, or immediately for dismissal.

- **Privileged access:** the ICT staff use a separate admin account for
  admin work, never for e-mail or browsing.

- **Access review:** every 6 months, department heads confirm that their
  staff's access is still right.

- **Physical security:** the server room is locked, with an entry log,
  and only ICT staff and approved visitors (signed in and escorted) may
  enter. Comms cabinets are locked.

- **Encryption:** laptops and carts are encrypted. Backups are
  encrypted. Wi-Fi uses WPA3.

- **Logging:** logs are kept for 12 months and reviewed weekly for
  repeated failed logins, new admin accounts and unusual traffic.

### 6.4 Incident response SOP

An **incident** is any event that threatens the safety of data or
systems, such as a virus, a lost laptop, a suspicious e-mail that was
opened, or unauthorised access.

| Severity | Example                                           | Response time                 | Who is told                           |
|----------|---------------------------------------------------|-------------------------------|---------------------------------------|
| Critical | Ransomware, patient data leaked, core system down | Immediate (within 15 minutes) | ICT Manager, CEO, Information Officer |
| High     | Virus on a ward PC, compromised account           | Within 1 hour                 | ICT Manager                           |
| Medium   | Repeated failed logins, lost device (encrypted)   | Within 4 hours                | ICT Manager                           |
| Low      | Spam, a single policy breach                      | Next working day              | ICT team                              |

**Steps:**

1.  **Identify and report:** staff report to the ICT help desk (phone,
    ticket or in person). The ticket is opened immediately.

2.  **Contain:** unplug the affected computer from the network (do not
    switch it off), disable the account, block the address on the
    firewall.

3.  **Preserve evidence:** save logs and note times. Do not wipe
    anything yet.

4.  **Eradicate:** remove the malware or fix the weakness, change
    affected passwords.

5.  **Recover:** restore from clean backups, check and return to
    service.

6.  **Notify:** if personal information may have been accessed, the
    Information Officer informs the Information Regulator and the
    affected people as soon as reasonably possible, as POPIA requires.

7.  **Learn:** hold a short review, record the cause and update the
    policies and training.

### 6.5 Patching and change management SOP

**Why:** most successful attacks use weaknesses that already have a fix.
And most outages come from unplanned changes.

**Patching schedule**

| Item                             | How often                                    | Process                                                             |
|----------------------------------|----------------------------------------------|---------------------------------------------------------------------|
| Windows and application updates  | Monthly                                      | Test on 2 pilot PCs, approve in WSUS, roll out to wards after hours |
| Critical security patches        | Within 7 days                                | Same process, faster                                                |
| Firewall, switch and AP firmware | Every 6 months, or sooner for security fixes | Back up configuration, upgrade one device at a time, test, record   |
| Endpoint protection definitions  | Automatic, checked weekly                    | ICT checks the dashboard for out-of-date machines                   |

**Change procedure** (aligned with the Change Control Board in the
Project Plan: Project Manager, IT Lead and Sponsor, later the ICT
Manager, Hospital IT lead and a clinical representative):

1.  **Request:** raise a change ticket stating what, why, who is
    affected, risk and rollback plan.

2.  **Approve:** the Change Board approves or rejects within 5 working
    days. Emergency changes need the ICT Manager and are reviewed
    afterwards.

3.  **Schedule:** do the change at a quiet time and tell affected wards
    in advance.

4.  **Back up** the current configuration first.

5.  **Do and test:** make the change and test it.

6.  **Roll back** if the test fails.

7.  **Record:** update the ticket, the asset register and the network
    diagram.

### 6.6 Acceptable use policy (summary)

Every staff member and contractor signs this before receiving a login.

- Hospital systems are for hospital work. Limited personal use is
  allowed if it does not slow the network or break these rules.

- Never share a password, and never log in as someone else.

- Lock the screen when leaving a computer. Patient information is not
  left visible on screens or printers.

- No unapproved software, USB drives, personal routers or hotspots on
  the hospital network.

- Do not click on suspicious links or attachments. Report them to ICT.

- Do not send patient information through personal e-mail or social
  media messages.

- Personal devices connect only to Hospital-Guest, unless approved for
  Hospital-Staff.

- The hospital may monitor use of its systems, as stated in the policy
  and as the law allows.

- Breaking this policy can lead to disciplinary action.

### 6.7 Hardware replacement and troubleshooting SOP

This SOP follows directly from the scenario: the 3 ICT staff must be
able to **install, troubleshoot (for example, reboot) and replace failed
units**.

#### Troubleshooting ladder

| Step | Action                                                                                                                                                                               | Time limit |
|------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------|
| 1    | Log the fault as a ticket and note the symptoms, who is affected, and when it began                                                                                                  | 5 min      |
| 2    | Check the basics: is the device on, are cables plugged in, is the link light on, is the problem with one user or many?                                                               | 10 min     |
| 3    | Check the monitoring dashboard for alarms (power, link, disk, temperature)                                                                                                           | 5 min      |
| 4    | **Restart** the affected device in the right order: for network, restart the edge device first (for example, the ward switch), then wait 3 minutes. For a PC, a normal restart first | 10 min     |
| 5    | Swap the cable, switch port or power supply to isolate the part                                                                                                                      | 15 min     |
| 6    | If not solved, **replace the unit** with a spare (below)                                                                                                                             | 30 min     |
| 7    | If still unsolved, escalate to the ICT Manager and then the vendor or the municipality, with the ticket number and what has been tried                                               | Immediate  |

**Correct restart order after a total power loss:** (1) UPS and power,
(2) core switches, (3) firewall and router, (4) NAS, (5) physical
servers, (6) virtual servers (DC1 and DC2 first), (7) ward switches and
access points, (8) printers and workstations. Shut down in the reverse
order.

#### Replacement procedure (swap, restore, update records)

| Device                                | Steps                                                                                                                                                                                                                                                                                                                             |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Access or core switch                 | 1\) Note the cable positions or use the patch schedule. 2) Power down the failed switch and unplug cables. 3) Mount the spare. 4) Load the saved configuration from MON1. 5) Reconnect cables one by one using the labels. 6) Test the links and wards. 7) Update the asset register. 8) Send the faulty unit for warranty repair |
| Wi-Fi access point                    | Unplug it, plug the spare into the same PoE port, wait for it to pick up its configuration, check the SSIDs on a phone, record                                                                                                                                                                                                    |
| Workstation or cart                   | Move the user's data if needed, deploy the spare with the standard image (about 1 hour), join it to the domain, test the user's applications, record                                                                                                                                                                              |
| Printer                               | Replace with the spare, assign the reserved address, add it to PRINT1, test print                                                                                                                                                                                                                                                 |
| Server component (disk, power supply) | Failed parts are hot-swappable. Replace them when the alert arrives and check that the RAID rebuilds                                                                                                                                                                                                                              |
| Firewall or router                    | Restore the latest saved configuration to the replacement, check rules and routes, test the link and VPN. The LTE backup keeps the hospital online while this is done                                                                                                                                                             |

#### Spares and records

- Spares on site: 1 access switch, 2 access points, 2 workstations, 1
  printer, spare fiber patch leads and SFP modules.

- Spares are replaced within 30 days of use, and the stock is counted
  every quarter.

- Every swap updates the asset register, including serial numbers and
  warranty dates.

- **Secure disposal:** before any computer leaves the hospital, its
  disks are wiped with a recognised tool (or physically destroyed) and
  the wipe is recorded. This applies to the 15 old computers.

### 6.8 Supplier and third-party access policy

Suppliers connect to the hospital to deliver orders, invoices and
support. Each supplier must:

1.  Sign an access agreement and confidentiality undertaking, covering
    POPIA.

2.  Have a named hospital sponsor, such as the supply chain manager.

3.  Use only the supplier VLAN or the VPN with MFA, and reach only the
    systems agreed.

4.  Use named individual accounts, which expire after 90 days unless
    renewed.

5.  Never keep patient data on their own devices unless the agreement
    allows it.

6.  Report any security incident that affects the hospital within 24
    hours.

The ICT team reviews the supplier accounts and logs every month, and
removes any account unused for 60 days.

### 6.9 Data protection (POPIA) policy

The hospital's **Information Officer** is responsible for this policy.
The aims are built into the design:

| POPIA principle                    | How the solution meets it                                                                                                         |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|
| Accountability                     | Named Information Officer and owners for each system                                                                              |
| Purpose and minimality             | Only needed data is collected and shown to staff in a role                                                                        |
| Security safeguards                | Segmentation, firewall, encryption, MFA, backups, logging (Sections 4 and 5)                                                      |
| Openness and rights of the patient | Patients can request access or correction through the records office, and the request is logged                                   |
| Breach notification                | SOP 6.4 step 6                                                                                                                    |
| Retention                          | Records kept for the period set in health records law, then securely destroyed. Backups follow the retention table in Section 4.4 |
| Cross-border transfers             | Cloud backup is stored in a South African data center                                                                             |

An annual POPIA compliance review is carried out by the Information
Officer, and a first audit takes place within 6 months of go-live, as
recommended in Task 1.

### 6.10 Power failure SOP

| Stage                                  | Action                                                                                                                                             | Who               |
|----------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| Power drops                            | UPS units take over. Monitoring sends an alert and the ICT team confirms that the generator has started                                            | ICT staff 1       |
| Under 15 minutes                       | No action beyond watching UPS battery levels on the dashboard                                                                                      | ICT staff 1       |
| Generator does not start in 15 minutes | Call Facilities. Warn the wards that systems may shut down. Shut down non-critical equipment (printers, guest Wi-Fi, test systems) to save battery | ICT Manager       |
| Battery at 30%                         | Gracefully shut down virtual servers, then hosts, then the NAS. The network core is the last thing to go                                           | ICT staff 2       |
| Power returns                          | Wait 5 minutes for stable power, then follow the restart order in 6.7 and test                                                                     | ICT staff 1 and 2 |
| After                                  | Record the outage, the UPS runtime achieved and any damage                                                                                         | ICT Manager       |

All policies are kept in the hospital document system, printed copies
are kept in the server room and with the ICT Manager, and each is
reviewed at the interval in the table at the start of this section.
Staff sign to say they have read the ones that apply to them.

## 7. Implementation, training and testing

The solution is rolled out over 12 months in the five phases already
approved in the Project Charter. Equipment is ordered early because
remote delivery is slow, and the power protection goes in before any
other equipment, a lesson taken from Task 1.

### 7.1 Implementation plan

| Phase                           | Months     | What is done in this solution                                                                                                                                                                                                        | Gate to pass                          |
|---------------------------------|------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|
| 1\. Initiation and planning     | M1 to M2   | Sign the municipal MOU and SLA. Site survey (fiber route, wards, Wi-Fi). Network design and IP plan finalised. Order the Openserve service. Tender documents issued. Stakeholder and community meetings                              | Charter approved (M2)                 |
| 2\. Procurement and preparation | M3 to M4   | Vendors selected on three quotations. Orders placed, backup vendor pre-qualified. Cabinets, UPS and electrical work prepared. Training curriculum written                                                                            | Hardware delivered and inspected (M4) |
| 3\. Infrastructure deployment   | M5 to M7   | Power protection first. Server room and cabinets. Structured cabling. Fiber route, splice and test. Core, firewall, router and Wi-Fi installed. Servers, virtual machines and backup configured. ICT staff shadow every installation | Network live and accepted (M7)        |
| 4\. Integration and testing     | M8 to M9   | Workstations imaged and deployed. Business applications connected. Trial and final data migration. Security testing and audit. User acceptance testing. ICT staff certification completed                                            | System accepted (M9)                  |
| 5\. Handover and sustainability | M10 to M12 | Documentation and SOPs signed off. Hand-over of warranties and licences. Monitoring on live. Quarterly restore test and continuity drill done once. Vendor support retainer in place. Post-implementation review                     | Project closure (M12)                 |

The detailed 26-week execution plan and WBS in the Project Plan (Task 1)
cover the build itself. This section is the 12-month schedule that
includes the community engagement, the carrier lead time and the
handover period.

### 7.2 Training plan for the ICT support staff (R7)

The scenario requires the three ICT staff to be trained to install
equipment, troubleshoot (for example, reboot), and replace failed units.
The training is **learning by doing**: they work next to the installers
on the real equipment, then do it themselves under supervision, then on
their own.

| Module                                    | Content                                                                                               | Method                                             | When     | Evidence of competence                                   |
|-------------------------------------------|-------------------------------------------------------------------------------------------------------|----------------------------------------------------|----------|----------------------------------------------------------|
| 1\. Network fundamentals                  | IP addressing, VLANs, switching and routing basics, how the hospital network is laid out              | Classroom and a set of the hospital's own diagrams | M3 to M4 | Written test, 75% pass                                   |
| 2\. Installing hardware                   | Mounting cabinets and switches, cabling and labelling, fitting APs, imaging a PC, setting up printers | Shadowing installers, then doing under supervision | M5 to M7 | Each person installs one cabinet and one PC without help |
| 3\. Fiber basics                          | Cleaning and inspecting connectors, reading test results, safe handling                               | Hands-on with the contractor                       | M6       | Demonstration                                            |
| 4\. Troubleshooting and reboot procedures | The troubleshooting ladder, restart order, reading the monitoring dashboard, using the ticket system  | Fault drills on the live network                   | M7 to M8 | Fix 5 planted faults within the time limits              |
| 5\. Replacing failed units                | The replacement SOP: swap switches, APs, PCs, printers, server parts, restore saved configurations    | Practical, each person does every swap             | M7 to M9 | Timed swap of a switch within 60 minutes                 |
| 6\. Security and backups                  | Firewall rules, endpoint dashboard, patching, backup checks and restore tests, incident response      | Vendor workshop                                    | M8 to M9 | Restore test and a tabletop incident exercise            |
| 7\. Certification                         | Industry entry-level certification such as CompTIA Network+ or equivalent (one per person)            | Accredited course and exam                         | M7 to M9 | Certificate (Charter deliverable, Month 9)               |

**Cost:** R36,000 for certification (3 x R12,000), R12,000 for vendor
workshops. The remaining R12,000 of the R60,000 training budget pays for
the end-user sessions below.

**Cross-training:** each ICT staff member has a main area (network,
servers, end users) and a backup area, so if anyone is absent, someone
else can do the work. A competency matrix is kept and reviewed every 6
months.

### 7.3 Training for the rest of the staff

| Group                            | What they learn                                                                  | Format                          | Size      |
|----------------------------------|----------------------------------------------------------------------------------|---------------------------------|-----------|
| Clinical staff                   | Logging in, locking screens, using shared workstations and carts, downtime forms | 1-hour ward sessions, per shift | About 330 |
| Administrative staff and finance | Logins, file shares, printing, e-mail safety, application access                 | 1-hour sessions in the offices  | About 145 |
| Contractors and suppliers        | Acceptable use and supplier policy                                               | Short briefing and signature    | About 100 |
| Managers                         | Their role in access reviews, incident reporting and the continuity plan         | 1-hour workshop                 | About 25  |

A small group of **ward champions** (one per ward) gets extra coaching
to give first-line help, which reduces pressure on the 3 ICT staff and
reduces resistance to change. The numbers above are estimates that add
up to the 600 staff.

### 7.4 Testing and acceptance

| Test                          | What is checked                                                                  | Pass criteria                                          | When                                                     |
|-------------------------------|----------------------------------------------------------------------------------|--------------------------------------------------------|----------------------------------------------------------|
| Fiber certification           | Light loss and faults on every core with OTDR                                    | Within standard limits, report issued                  | M6                                                       |
| Throughput and latency        | Speed test from the core to the internet and to the provincial data center       | At least 100 Mbps both directions, latency under 20 ms | M7                                                       |
| Failover tests                | Pull the fiber, fail a core switch, stop a host                                  | Service continues within the RTOs in Section 6.1       | M7 to M8                                                 |
| Wi-Fi coverage                | Signal and speed walk test in every ward and office                              | At least 25 Mbps and good signal in every ward         | M7                                                       |
| Security tests                | Vulnerability scan of servers and network, firewall rule review                  | Zero critical vulnerabilities (Charter)                | M8 to M9                                                 |
| Data migration                | Trial migration, then final, with record counts and sample checks by data owners | 100% accuracy, no unrecoverable loss (Charter)         | Trial at least 4 weeks before go-live, final in M8 to M9 |
| User acceptance testing (UAT) | Each department tests its daily tasks on the new system                          | Written sign-off by every department                   | M9                                                       |
| Backup and restore            | Restore a file, then a whole virtual server                                      | Within RTO and data matches                            | M8 and quarterly                                         |
| ICT competency                | Practical assessments in Section 7.2                                             | All 3 staff pass without outside help                  | M9                                                       |

### 7.5 Documentation delivered at handover

| Document                                   | Contents                                                                                           |
|--------------------------------------------|----------------------------------------------------------------------------------------------------|
| Network architecture diagrams              | Logical, physical (as built, including the fiber route and splice point) and cloud backup diagrams |
| IP and VLAN plan                           | Sections 5.4 and 5.5, updated as built                                                             |
| Configuration backups                      | Every device configuration, with the date                                                          |
| Asset register                             | Serial numbers, locations, warranty and licence dates                                              |
| Test and acceptance reports                | OTDR, throughput, security, migration and UAT sign-offs                                            |
| Policies and SOPs                          | Section 6, signed and approved                                                                     |
| Training records and manuals               | Attendance, assessments, certificates, user guides                                                 |
| Warranty certificates and support contacts | Vendors, municipality, Openserve, support retainer                                                 |
| Sustainability plan                        | Section 8                                                                                          |
| Closure and lessons-learned report         | Final report to the Hospital CEO                                                                   |

## 8. Sustainability, stakeholders and budget

The scenario opens with a warning: a network built on top of human
networks that are not working will not last. So the project treats the
people side as seriously as the cables. Self-sustaining here means three
things after Month 12: the hospital can **run** the system (skills and
procedures), **pay** for it (a known running budget), and **keep the
goodwill** of the people it depends on (municipality, carrier,
community).

### 8.1 The human network: stakeholder actions

| Stakeholder                                  | What they need                                                | What the project does                                                                                                                                                                                                         |
|----------------------------------------------|---------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Hospital CEO (sponsor)                       | Safe, reliable care and data, with value for money            | Bi-weekly status reports. Early sign-off of policies. Running costs shown from day one                                                                                                                                        |
| ICT Manager and 3 ICT staff                  | Manageable workload and real skills                           | Training by doing (7.2), SOPs, ticketing, vendor retainer for year one. Their input shapes the design                                                                                                                         |
| Municipality (Municipal IT Director)         | A clear agreement, no risk to its own network, shared benefit | MOU and SLA in Month 1 to 2, municipal technician present at the splice, spare fiber cores for future shared use, and recognition of the municipality's role                                                                  |
| Openserve                                    | A clear service order and a customer who pays on time         | Service ordered early, named contacts on both sides, quarterly service review                                                                                                                                                 |
| Clinical and administrative staff            | Systems that make work easier, not harder                     | Ward champions, short training per shift, paper downtime forms, a clear help desk                                                                                                                                             |
| Suppliers                                    | Access that works and is fair                                 | Supplier VLAN, written terms, named sponsor (6.8)                                                                                                                                                                             |
| Community leaders, patients and the district | Better care, no disruption, local benefit                     | Briefing to traditional and civic leaders before the fiber work starts. Local labour used for digging, pole work and labelling where skills allow. Guest Wi-Fi for patients and visitors. Updates in the community newsletter |

### 8.2 Budget (approved Charter budget)

| Category                          | Estimate (ZAR)  | Detail                                                            |
|-----------------------------------|-----------------|-------------------------------------------------------------------|
| Fiber infrastructure and splicing | R 180 000       | Section 3.2                                                       |
| Network hardware (core)           | R 250 000       | Section 3.3                                                       |
| End-user devices                  | R 320 000       | Section 3.4                                                       |
| Server and storage                | R 190 000       | Section 3.5                                                       |
| Software licensing and security   | R 140 000       | Section 4.1                                                       |
| Training and change management    | R 60 000        | Section 7.2 and 7.3                                               |
| Contingency (10% of R1,140,000)   | R 114 000       | Remote logistics, currency changes, air conditioning, small tools |
| **Total**                         | **R 1 254 000** | Excludes VAT and running costs                                    |

The six cost lines above the contingency total R1,140,000. The 10%
contingency (R114,000) is held by the project manager and released only
through the change process.

### 8.3 Running costs after handover (approximate, per year)

These costs are **not** in the project budget and must be placed in the
hospital's operating budget before the project ends.

| Item                                      | Estimate per year (ZAR) | Note                                                                                                                          |
|-------------------------------------------|-------------------------|-------------------------------------------------------------------------------------------------------------------------------|
| Openserve dedicated link (100 Mbps)       | R 120 000               | Confirmed at tender. A 500 Mbps upgrade is about R300,000 (Task 1, Proposal 2)                                                |
| Municipal fiber maintenance under the SLA | R 24 000                | Amount negotiated in the MOU                                                                                                  |
| Software and subscription renewals        | R 102 000               | Endpoint protection, firewall subscription, backup software, cloud backup                                                     |
| Vendor support retainer                   | R 60 000                | The Charter plans a year-one retainer, which has no separate budget line, so fund it from the contingency or operating budget |
| Spares, cables, consumables               | R 20 000                | Replace used spares (Section 6.7)                                                                                             |
| LTE backup data                           | R 4 000                 | Small monthly plan                                                                                                            |
| Refresher training                        | R 10 000                | Certification refresh and new-starter training                                                                                |
| **Estimated total**                       | **R 340 000**           | About 27% of the project cost per year                                                                                        |

### 8.4 What keeps the project self-sustaining

1.  **Skills stay:** three certified local staff, cross-trained, with
    written SOPs, so the hospital does not depend on outside people for
    daily work.

2.  **Standard and simple:** one switch model, one AP model, one PC
    image, so spares and knowledge are shared.

3.  **Costs known and planned:** the running costs above go into the
    annual budget, and the Provincial Health ICT budget is the fall-back
    source (Task 1, funding strategy).

4.  **Agreements in writing:** the municipal SLA, the Openserve service
    contract and the vendor retainer all have named contacts and
    response times.

5.  **Room to grow:** spare fiber cores, 10G uplinks and spare switch
    ports mean the Task 1 proposals (the 500 Mbps upgrade, five more
    telemedicine clinics, NHLS integration) can be added without
    rebuilding.

6.  **Shared benefit:** spare fiber cores can later serve other public
    buildings, spreading the cost and giving the municipality a reason
    to protect the link.

7.  **Review:** a six-month post-implementation review checks the
    Charter success criteria and updates the policies.

### 8.5 Main risks for this solution

| Risk                                                            | Likelihood | Impact | Response                                                                                                                                    |
|-----------------------------------------------------------------|------------|--------|---------------------------------------------------------------------------------------------------------------------------------------------|
| Municipal approval or splice permission is delayed              | Medium     | High   | Start the MOU in Month 1, escalate through the Municipal IT Director and CEO, the design allows a temporary LTE link while waiting          |
| Openserve service takes longer than expected in a rural area    | Medium     | High   | Order in Month 2, track weekly with a named contact, use the LTE backup as an interim link                                                  |
| Theft or damage of the fiber or copper cable (a common problem) | Medium     | High   | Armoured cable, buried or aerial on existing structures, route markers, community engagement, link monitoring that alerts on loss of signal |
| Power instability                                               | High       | Medium | UPS everywhere, generator-ready design, power SOP (6.10)                                                                                    |
| ICT staff leave after training                                  | Medium     | High   | Cross-training, documented SOPs, vendor retainer, retention discussion with the hospital                                                    |
| Costs rise because of remote logistics or currency changes      | High       | Medium | 10% contingency, fixed-price contracts, early orders                                                                                        |
| Resistance from clinical staff                                  | Medium     | Medium | Ward champions, short training, paper fall-back, early involvement                                                                          |

## 9. Network architecture diagrams

Three diagrams describe the same network from three angles. The physical
diagram shows the equipment and where it sits. The logical diagram shows
how traffic is organized and addressed. The cloud diagram shows what the
hospital uses outside its own walls. Each one answers a different
question, so each one is drawn separately.

| Diagram                       | Question it answers                                               | Who uses it                                                   |
|-------------------------------|-------------------------------------------------------------------|---------------------------------------------------------------|
| Figure 9.1 Physical           | What equipment do we have, where is it, and how is it cabled?     | ICT staff doing installs, swaps and fault finding             |
| Figure 9.2 Logical            | How is the network divided, addressed and protected?              | ICT staff configuring the firewall and switches, and auditors |
| Figure 9.3 Cloud and external | Which outside services do we depend on, and how do we reach them? | ICT Manager, CEO, and anyone managing contracts               |

### 9.1 Physical network diagram (Figure 9.1)

<img src="task2-project-solution/media/image1.png"
style="width:6.5in;height:4.1in" />

The physical diagram follows the cable from the municipal network to a
ward device.

| Part of the diagram | What is shown                                                                                             | Link type and speed                                                             |
|---------------------|-----------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------|
| External            | Openserve service delivered at the municipal node                                                         | Handover to the municipality's network                                          |
| Splice point        | Municipal closure where the hospital fiber is spliced in                                                  | 24-core single-mode fiber, 2 cores lit                                          |
| Hospital entry      | Fiber patch panel (ODF) in the server room                                                                | Single-mode fiber, 1 km run                                                     |
| Edge                | Edge router with LTE failover modem                                                                       | 1 Gbps to firewall                                                              |
| Security            | Next-generation firewall                                                                                  | 1 Gbps to core                                                                  |
| Core                | Core switch 1 and core switch 2, stacked                                                                  | 10G SFP+ between them                                                           |
| Servers             | Host A, Host B and NAS                                                                                    | 1 Gbps to each core switch, one cable to each                                   |
| Distribution        | Ward cabinets CAB-A to CAB-E and administration cabinet CAB-F, each with an access switch and a 1 kVA UPS | 1 Gbps fiber or Cat6 uplink back to the core (fiber where the run is over 90 m) |
| Edge devices        | Access points (ceiling), workstations, carts, printers                                                    | Cat6 from the access switch, powered over Ethernet for the access points        |
| Power               | 3 kVA online UPS for the server room, generator changeover socket                                         | Mains, UPS, generator                                                           |

#### Server room cabinet layout (12U)

A rack diagram shows what sits in each slot of the cabinet. It lets the
ICT team find a device without opening every door.

| Slot      | Equipment                                    | Notes                                                   |
|-----------|----------------------------------------------|---------------------------------------------------------|
| U12       | Fiber patch panel (ODF)                      | Incoming hospital fiber from the municipal splice point |
| U11       | Edge router                                  | Fiber WAN and LTE failover                              |
| U10       | Firewall                                     | Inside, Guest and Supplier/DMZs                         |
| U9        | Core switch 1                                | Stacked with core switch 2                              |
| U8        | Core switch 2                                |                                                         |
| U7        | Access switch (administration offices)       |                                                         |
| U6 and U5 | Host A (2U server)                           | Runs DC1, FILE1, APP1, BKP1                             |
| U4 and U3 | Host B (2U server)                           | Runs DC2, PRINT1, WSUS1, MON1                           |
| U2        | NAS (1U, 4 disks)                            | Local backup and file storage                           |
| U1        | Power distribution unit and cable management | Fed from the UPS                                        |

The 3 kVA UPS is a floor-standing unit beside the cabinet. Every cable
is labelled at both ends with the name of the device and the port, for
example sw-cab-a-01 port 12.

### 9.2 Logical network diagram (Figure 9.2)

<img src="task2-project-solution/media/image2.png"
style="width:6.5in;height:4.21667in" />

The logical diagram ignores cable routes and shows addresses, zones, and
traffic rules. It is a VLAN diagram combined with a view of the firewall
zones.

| Zone                       | VLAN              | Subnet                               | Gateway    | Key devices and addresses                                                                 |
|----------------------------|-------------------|--------------------------------------|------------|-------------------------------------------------------------------------------------------|
| Outside                    | n/a               | Public address supplied by Openserve | Openserve  | Firewall outside interface, VPN service                                                   |
| Transit (core to firewall) | n/a               | 10.10.0.0/29                         | n/a        | Core switches and firewall inside interface                                               |
| Inside                     | 10 Management     | 10.10.10.0/24                        | 10.10.10.1 | Host A 10.10.10.21, Host B 10.10.10.22, switches and APs from 10.10.10.31                 |
| Inside                     | 20 Clinical       | 10.10.20.0/23                        | 10.10.20.1 | Ward workstations, carts                                                                  |
| Inside                     | 30 Administration | 10.10.30.0/24                        | 10.10.30.1 | Offices, finance, supply chain                                                            |
| Inside                     | 40 Servers        | 10.10.40.0/24                        | 10.10.40.1 | DC1 .10, DC2 .11, FILE1 .12, PRINT1 .13, APP1 .14, WSUS1 .15, MON1 .16, BKP1 .17, NAS .20 |
| Inside                     | 50 Printers       | 10.10.50.0/24                        | 10.10.50.1 | Printers on reserved addresses                                                            |
| Inside                     | 60 Staff Wi-Fi    | 10.10.60.0/23                        | 10.10.60.1 | Staff phones, tablets, laptops                                                            |
| Guest                      | 70 Guest Wi-Fi    | 10.10.70.0/23                        | 10.10.70.1 | Patients and visitors, internet only                                                      |
| Supplier/DMZ               | 80 Supplier       | 10.10.80.0/24                        | 10.10.80.1 | Approved supplier devices, VPN users                                                      |

**Traffic paths to show as arrows on the diagram:**

1.  Clinical and Administration to Servers: directory login, file
    sharing, printing, application ports.

2.  Staff Wi-Fi to Servers: same ports as above.

3.  Servers and staff to the internet through the firewall, with web
    filtering.

4.  Guest to the internet only, capped at 10 Mbps in total. No arrow to
    any other zone.

5.  Supplier to APP1 only, over HTTPS, after MFA.

6.  ICT admin workstations to Management (10): SSH, HTTPS and SNMPv3.

7.  Print server to Printers (50).

8.  Servers to the cloud backup address, encrypted.

9.  VPN from outside for ICT and approved suppliers, ending in the
    Supplier/DMZ or the Management VLAN.

Everything not drawn as an arrow is blocked.

### 9.3 Cloud and external interaction diagram (Figure 9.3)

<img src="task2-project-solution/media/image3.png"
style="width:6.5in;height:4.25833in" />

This diagram puts the hospital network in the middle and shows what it
talks to outside. Most of the hospital's systems stay on its own
servers. The scenario asks for a hybrid model, so only backups, security
updates, remote support, and the public website live elsewhere.

| External party                           | Connection                                                  | What passes over it                                           | Direction                       |
|------------------------------------------|-------------------------------------------------------------|---------------------------------------------------------------|---------------------------------|
| Openserve and the internet               | Dedicated fiber via the municipal network, LTE as backup    | All internet traffic                                          | Both                            |
| Provincial and national health systems   | Through the firewall over the same link                     | Reporting and access to systems that run outside the hospital | Both                            |
| Cloud backup (South African data center) | Encrypted HTTPS, nightly                                    | Encrypted copies of server backups                            | Hospital to cloud               |
| Firewall and endpoint security vendors   | HTTPS to the vendor's update and console service            | Signatures, policy updates, alerts                            | Mostly cloud to hospital        |
| Microsoft update service                 | HTTPS to WSUS1 only                                         | Windows patches, then approved and distributed internally     | Cloud to hospital               |
| Vendor support (retainer)                | Time-limited VPN with MFA                                   | Remote fixes under a ticket                                   | Vendor to hospital              |
| Approved suppliers                       | Supplier VLAN or VPN with MFA                               | Orders, invoices, delivery notices                            | Both                            |
| Website host                             | Public internet only. No connection to the hospital network | Public information pages                                      | Internet to host                |
| Mobile network (LTE)                     | LTE modem on the edge router                                | Failover internet traffic                                     | Both, only during a fiber fault |

The diagram should make three things clear to a reader. All outside
traffic enters through one firewall. The website host sits entirely
outside the hospital network. Backups leave the hospital encrypted and
never return unless restoration is needed.

### 9.4 Reading the diagrams

- Use the same device names in all three figures, for example core-sw-01
  and srv-host-a, so a reader can follow one device across diagrams.

- Each figure has a legend for line types: solid for fiber, solid
  thinner for copper, dashed for LTE or VPN.

- Each figure has a title, a version number, and a date. They are
  updated whenever the network changes (SOP 6.5).

- The editable Visio files are part of the handover pack (Section 7.5).

## 9. Network architecture diagrams

Three diagrams describe the network from three angles, following the
logical, physical, and cloud views explained in the Gliffy network
diagram guide. They are in the file *hospital_network_diagrams.pptx*
(one slide each) and use the same VLAN numbers, device names and
addresses as Sections 3 to 5.

| Diagram                | What it shows                                                | Main details                                                                                                                                                                           |
|------------------------|--------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1\. Logical            | How traffic is organized and moves, not where the cables run | Internet to Openserve to municipal splice point to hospital router, firewall, and core. Eight VLANs with their subnets. Three firewall zones: Inside, Guest, and Supplier              |
| 2\. Physical           | Where each device actually sits and how it is cabled         | 1 km fiber from the municipal splice point to the fiber patch panel. 12U server-room cabinet laid out unit by unit. UPS and generator changeover. Six ward cabinets with their uplinks |
| 3\. Cloud and external | What the hospital connects to outside its own walls          | Openserve link, 4G/LTE failover, off-site cloud backup in South Africa, provincial and national health systems, vendor security services, remote ICT and supplier access over VPN      |

## 10. Outsourced services

The hospital has three ICT staff, so some work is better bought than
built. These services are outsourced, each under a written agreement
with a named contact and a response time. The hospital keeps control of
the data and the decisions, and the supplier does the specialist work.

| Service                      | Provider                                                                  | What it covers                                                                      | Service level and cost                                                                                                |
|------------------------------|---------------------------------------------------------------------------|-------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| Dedicated internet link      | Openserve (only carrier in the district)                                  | Internet service delivered at the municipal node, 100 Mbps symmetrical              | 99.5% monthly availability. About R120,000 a year, confirmed at tender.                                               |
| Fiber route and splice point | Sekhukhune municipality, under the SLA                                    | Upkeep of the municipal network and the 1 km extension                              | Technician on site within 4 hours, repair within 24 hours. About R24,000 a year                                       |
| Security subscriptions       | Firewall and endpoint security vendors                                    | Threat updates for the firewall, endpoint protection console                        | Renewed yearly. About R52,000 a year (firewall R30,000 plus endpoint R22,000)                                         |
| Off-site cloud backup        | South African cloud backup provider                                       | Encrypted copy of server backups, kept 90 days with monthly copies for 12 months.   | Data stays in South Africa for POPIA. R30,000 in year one                                                             |
| Vendor support retainer      | The network and server supplier                                           | Help with hard faults, configuration changes, firmware upgrades, remote assistance. | Response within 4 business hours. About R60,000 a year. Year-one funding comes from contingency.                      |
| Hardware warranty and repair | Equipment manufacturers                                                   | Swapping faulty switches, servers, PCs and printers                                 | Three-year warranty on workstations. Other items follow the supplier's terms.                                         |
| Website hosting and e-mail   | Provincial health department or a South African hosting company (assumed) | The hospital's public information page, contact details and staff e-mail            | No patient data on the website. Cost from the operating budget, to be confirmed                                       |
| SMS alerts                   | SMS gateway provider                                                      | Text messages from the monitoring system to ICT staff when something fails          | Pay per message, a few hundred rand a year                                                                            |
| Independent security testing | External security firm                                                    | Vulnerability scan before go-live and again each year                               | Needed to prove the "zero critical vulnerabilities" criterion. Cost to be quoted, funded from contingency in year one |
| Certification training       | Accredited training provider                                              | Entry-level networking certificates for the three ICT staff                         | R36,000 in the training budget                                                                                        |

**What stays in-house:** day-to-day help desk, user accounts and access
reviews, patching, backup checks and restore tests, hardware swaps, and
the policies in Section 6.

**How the contracts are managed**

- The ICT Manager owns every supplier relationship and keeps a register
  of contacts, contract end dates and renewal costs.

- Each supplier signs a data protection clause. Where a supplier handles
  personal information, a POPIA operator agreement is added.

- Service levels are reviewed every quarter. Missed targets are recorded
  in the help desk system.

- Renewal dates go into the ICT calendar 90 days ahead, so licenses
  never lapse by accident.

## 11. Other IT support for the hospital's business processes

Network and servers only help if the people using them can get problems
fixed quickly. This section covers the support that keeps the hospital's
daily work moving.

### 11.1 Help desk and support levels

| Level   | Who                             | Handles                                                                                       |
|---------|---------------------------------|-----------------------------------------------------------------------------------------------|
| Level 0 | Ward champions (one per ward)   | Simple questions, password help, showing a colleague how to use a cart or printer             |
| Level 1 | ICT support staff               | Logged tickets: faults, accounts, printers, PCs, Wi-Fi. Restarts and spare swaps from SOP 6.7 |
| Level 2 | ICT Manager                     | Network, server and security issues, access reviews, supplier calls                           |
| Level 3 | Vendor, municipality, Openserve | Faults beyond the hospital's own equipment or skills                                          |

Staff report problems by phone, in person or through the help desk
system (GLPI). Every call becomes a ticket with a number, an owner and a
time stamp.

### 11.2 Priorities and target times

| Priority   | Example                                                        | Response      | Target fix     |
|------------|----------------------------------------------------------------|---------------|----------------|
| 1 Critical | Network down, patient system unavailable, suspected ransomware | 15 minutes    | 4 hours        |
| 2 High     | A whole ward without network or printing                       | 1 hour        | 8 hours        |
| 3 Medium   | One PC or printer not working                                  | 4 hours       | 2 working days |
| 4 Low      | New user, software request, advice                             | 1 working day | 5 working days |

Cover hours are 07:00 to 17:00 on working days. After hours, the on-call
ICT staff member takes priority 1 calls by phone. The router is shared
evenly between the three staff.

### 11.3 Which support serves which business process

| Hospital process                       | What it depends on                                             | IT support that keeps it working                                            |
|----------------------------------------|----------------------------------------------------------------|-----------------------------------------------------------------------------|
| Admitting patients and finding records | Central file server, ward PCs and Wi-Fi, patient system access | Spare PCs, backups with restore tests, 4-hour target for the record systems |
| Prescribing and printing               | Print server, ward printers                                    | One spare printer, print queue monitoring, printer swap SOP                 |
| Finance and audit                      | Finance system access, file shares, user logs                  | Role-based access, log retention for 12 months, quarterly access review     |
| Supply chain and suppliers             | Supplier VLAN and VPN, application gateway                     | Supplier agreements, monthly account review, MFA                            |
| Management reporting                   | Reliable connection to provincial systems                      | Monitoring of the Openserve link, LTE failover, quarterly service review    |
| Staff onboarding and leaving           | Accounts, devices, training                                    | HR-to-ICT notice process, standard PC image, onboarding briefing            |

### 11.4 Supporting routines

- **Monitoring:** Zabbix watches the link, firewall, switches, access
  points, servers, disk space and UPS batteries, and sends alerts to ICT
  staff.

- **Asset register:** every device has a record with serial number,
  location, and warranty date, updated at every swap.

- **Patching and change control:** monthly patching and written change
  tickets, as in SOP 6.5.

- **Backup and restore** daily report checks and quarterly restore
  tests, as in SOP 6.2.

- **Knowledge base:** the help desk stores fixes found for repeat
  problems, so the next person solves them faster.

- **Capacity review:** every six months, the ICT Manager checks link
  usage, storage, and Wi-Fi load. If peak use passes 70% of the link,
  the 500 Mbps upgrade (Task 1, Proposal 2) goes to the Change Board.

- **Refresher training:** short sessions for new staff and yearly
  updates forward champions.

## 12. Conclusion and references

The proposed solution gives the New Jane Furse Memorial Hospital a
dedicated 1 km fiber extension from the municipal network, a secure and
segmented internal network, modern shared workstations, resilient
servers with three layers of backup, and the policies and procedures to
run it safely. It fits the R1,254,000 Charter budget and the 12-month
timeline. Its long-term success rests on three things the scenario
stressed: a trained local ICT team, written procedures that anyone on
the team can follow, and strong working relationships with the
municipality, Openserve, staff, suppliers and the community.

### References

- Republic of South Africa (2013) *Protection of Personal Information
  Act 4 of 2013*. Pretoria: Government Printer.

- International Organization for Standardization (2022) *ISO/IEC
  27001:2022 Information security, cybersecurity and privacy protection:
  Information security management systems: Requirements*. Geneva: ISO.

- South African Bureau of Standards (SABS) *SANS 10142-1: The wiring of
  premises, Part 1: Low-voltage installations*. Pretoria: SABS.

- National Department of Health (South Africa) *Health Normative
  Standards Framework for Interoperability in eHealth*. Pretoria: NDoH.

- Project Management Institute (2021) *A Guide to the Project Management
  Body of Knowledge (PMBOK Guide)*, 7th edn. Newtown Square, PA: PMI.

- Task 1 of this assignment: Project Charter, Project Plan, Project
  Proposals and Project Report, Sekhukhune hospital IT infrastructure
  project.

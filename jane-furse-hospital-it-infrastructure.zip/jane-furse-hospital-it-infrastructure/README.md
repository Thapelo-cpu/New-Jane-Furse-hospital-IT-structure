# New Jane Furse Memorial Hospital: IT Infrastructure Project

Final project for the IT infrastructure upgrade of New Jane Furse Memorial Hospital, Sekhukhune District, Limpopo.

The hospital is 1 km from the municipal network. The project extends that network to the hospital over a dedicated fibre link, connects it to the internet through Openserve, and builds a secure internal network, modern workstations, central storage with backup, and a trained local ICT team. It is planned for 12 months with a budget of R1,254,000.

## Contents

| Task | Document | Formats |
|------|----------|---------|
| Task 1: Project Charter, Project Plan and Proposals | `docs/task1-project-charter-and-plan/` | [PDF](docs/task1-project-charter-and-plan/Task1_Project_Charter_and_Plan.pdf), [Markdown](docs/task1-project-charter-and-plan/Task1_Project_Charter_and_Plan.md), DOCX |
| Task 2: Project Solution (hardware, software, network, policies and SOPs) | `docs/task2-project-solution/` | [PDF](docs/task2-project-solution/Task2_Project_Solution.pdf), [Markdown](docs/task2-project-solution/Task2_Project_Solution.md), DOCX |

## Project pillars

1. Connectivity: dedicated fibre link, at least 100 Mbps symmetrical, 99.5% uptime target
2. Infrastructure modernisation: new workstations, printers, servers, central storage and backup
3. Cybersecurity: firewall, intrusion detection, endpoint protection, network segmentation
4. Operational efficiency: stable access to operations, finance, supply chain and patient record systems
5. Capacity building: training for the ICT team, written SOPs and handover documentation

## Task 1 summary

- Project Charter: objectives, scope, stakeholders, risks, budget, timeline, success criteria
- Project Plan: phases, work breakdown structure, resources, quality, change and procurement management
- Proposals: telemedicine expansion, internet backbone upgrade, NHLS laboratory integration

## Task 2 summary

- Requirements analysis (R1 to R7) and network sizing
- Hardware and software bills of materials
- Network design: topology, fibre splice, VLANs, firewall rules, Wi-Fi, QoS
- Policies and SOPs, including business continuity and disaster recovery
- Training and sustainability plan

## Repository structure

```
docs/
  task1-project-charter-and-plan/
  task2-project-solution/
images/
README.md
```

## Author

YOUR NAME (student number)
